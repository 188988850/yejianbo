<?php
/*今日更新*/
if (!defined('IN_CRONLITE')) die();

if($_GET['buyok']==1||$_GET['chadan']==1){include_once TEMPLATE_ROOT.'storenews/query.php';exit;}
if(isset($_GET['tid']) && !empty($_GET['tid']))
{
	$tid=intval($_GET['tid']);
    $tool=$DB->getRow("select tid from pre_tools where tid='$tid' limit 1");
    if($tool)
    {
		exit("<script language='javascript'>window.location.href='./?mod=buy&tid=".$tool['tid']."';</script>");
    }
}

$cid = intval($_GET['cid']);
if(!$cid && !empty($conf['defaultcid']) && $conf['defaultcid']!=='0'){
	$cid = intval($conf['defaultcid']);
}
$ar_data = [];
$classhide = explode(',',$siterow['class']);
$re = $DB->query("SELECT * FROM `pre_class` WHERE `active` = 1 AND cidr=0 ORDER BY `sort` ASC ");
$qcid = "";
$cat_name = "";
while ($res = $re->fetch()) {
    if($is_fenzhan && in_array($res['cid'], $classhide))continue;
    if($res['cid'] == $cid){
    	$cat_name=$res['name'];
    	$qcid = $cid;
    }
    $ar_data[] = $res;
}
?>
<!DOCTYPE html>
<html lang="zh" style="font-size: 102.4px;">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="dc_coverage" content="CN">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="format-detection" content="telephone=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="wap-font-scale" content="no"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no"/>
    <script> document.documentElement.style.fontSize = document.documentElement.clientWidth / 750 * 40 + "px";</script>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>今日更新</title>  
<link rel="stylesheet" type="text/css" href="../assets/store/css/foxui.css">
    <link rel="stylesheet" type="text/css" href="../assets/store/css/foxui.diy.css">
    <link rel="stylesheet" type="text/css" href="../assets/store/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/store/css/iconfont.css">
    <link rel="stylesheet" type="text/css" href="../assets/store/css/index.css">
    <link rel="stylesheet" type="text/css" href="//cdn.staticfile.org/layui/2.5.7/css/layui.css">
  </head>
<style>body{ background:#ecedf0 url("https://api.dujin.org/bing/1920.php") fixed;background-repeat:no-repeat;background-size:100% 100%;}</style></head>
<body>
  <style type="text/css">
 

    .fui-page.fui-page-from-center-to-left,
    .fui-page-group.fui-page-from-center-to-left,
    .fui-page.fui-page-from-center-to-right,
    .fui-page-group.fui-page-from-center-to-right,
    .fui-page.fui-page-from-right-to-center,
    .fui-page-group.fui-page-from-right-to-center,
    .fui-page.fui-page-from-left-to-center,
    .fui-page-group.fui-page-from-left-to-center {
        -webkit-animation: pageFromCenterToRight 0ms forwards;
        animation: pageFromCenterToRight 0ms forwards;
    }

    .fix-iphonex-bottom {
        padding-bottom: 34px;
    }

    .fui-goods-item .detail .price .buy {
        color: #fff;
        background: #1492fb;
        border-radius: 3px;
        line-height: 1.1rem;
    }

    .fui-goods-item .detail .sale {
        height: 1.7rem;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        font-size: 0.65rem;
        line-height: 0.9rem;
    }

    .goods-category {
        display: flex;
        background: #fff;
        flex-wrap: wrap;
    }

    .goods-category li {
        width: 25%;
        list-style: none;
        margin: 0.4rem 0;
        color: #666;
        font-size: 0.65rem;

    }

    .goods-category li.active p {
        background: #1492fb;
        color: #fff;
    }


    .goods-category li p {
        width: 4rem;
        height: 2rem;
        text-align: center;
        line-height: 2rem;
        border: 1px solid #ededed;
        margin: 0 auto;
        -webkit-border-radius: 0.1rem;
        -moz-border-radius: 0.1rem;
        border-radius: 0.1rem;
    }

    .footer ul {
        display: flex;
        width: 100%;
        margin: 0 auto;
    }

    .footer ul li {
        list-style: none;
        flex: 1;
        text-align: center;
        position: relative;
        line-height: 2rem;
    }

    .footer ul li:after {
        content: '';
        position: absolute;
        right: 0;
        top: .8rem;
        height: 10px;
        border-right: 1px solid #999;


    }

    .footer ul li:nth-last-of-type(1):after {
        display: none;
    }

    .footer ul li a {
        color: #999;
        display: block;
        font-size: .6rem;
    }

    .fui-goods-group.block .fui-goods-item .image {
        width: 100%;
        margin: unset;
        padding-bottom: unset;
     height: 5rem;
    

    }

    .layui-flow-more {
        width: 100%;
        float: left;
    }
.fui-goods-group .fui-goods-item .detail .name {
    height: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    font-size: .6rem;
    color: #262626;
}
    .fui-goods-group .fui-goods-item .image img {
        border-radius: 10px;
    }

    .fui-goods-group .fui-goods-item .detail .minprice {
        font-size: .6rem;
    }

    .fui-goods-group .fui-goods-item .detail .name {
        height: 100%;
    }

    .swiper-pagination-bullet {
        width: 20px;
        height: 20px;
        text-align: center;
        line-height: 20px;
        font-size: 12px;
        color: #000;
        opacity: 1;
        background: rgba(0, 0, 0, 0.2);
    }

    .swiper-pagination-bullet-active {
        color: #fff;
        background: #ed414a;
    }

    .swiper-pagination {
        position: unset;
    }

    .swiper-container {
        --swiper-theme-color: #ff6600; /* 设置Swiper风格 */
        --swiper-navigation-color: #007aff; /* 单独设置按钮颜色 */
        --swiper-navigation-size: 18px; /* 设置按钮大小 */
    }

    .goods_sort {
        position: relative;
        width: 100%;

        -webkit-box-align: center;
        padding: .4rem 0;
        background: #fff;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
    }

    .goods_sort:after {
        content: " ";
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        border-bottom: 1px solid #e7e7e7;
    }

    .goods_sort .item {
        position: relative;
        width: 1%;
        display: table-cell;
        text-align: center;
        font-size: 0.7rem;
        border-left: 1px solid #e7e7e7;
        color: #666;
    }

    .goods_sort .item .sorting {
        width: .2rem;
        height: .2rem;
        position: relative;
    }

    .goods_sort .item:first-child {
        border: 0;
    }

    .goods_sort .item.on .text {
        color: #1195da;
    }

    .goods_sort .item .sorting .icon {
        /*font-size: 11px;*/
        position: absolute;
        -webkit-transform: scale(0.6);
        -ms-transform: scale(0.6);
        transform: scale(0.6);
    }

    .goods_sort .item-price .sorting .icon-sanjiao1 {
        top: .15rem;
        left: 0;
    }

    .goods_sort .item-price .sorting .icon-sanjiao2 {
        top: -.15rem;
        left: 0;
    }

    .goods_sort .item-price.DESC .sorting .icon-sanjiao1 {
        color: #1195da
    }

    .goods_sort .item-price.ASC .sorting .icon-sanjiao2 {
        color: #1195da
    }

    .content-slide .shop_active .icon-title {
        color: #1195da;
    }
    .content-slide .shop_active .mbg {
        background-color: #eff5fd;
    }

    .content-slide .shop_active img {
        filter: saturate(100%);
    }

    .xz {
        background-color: #3399ff;
        color: white !important;
        border-radius: 5px;
    }

    .tab_con > ul > li.layui-this {
        background: linear-gradient(to right, #73b891, #53bec5);
        color: #fff;
        border-radius: 6px;
        text-align: center;
    }

    .fui-notice:after {

        border: 0px solid #e2e2e2;

    }

    .fui-notice:before {

        border: 0px solid #e2e2e2;
    }

    #audio-play #audio-btn {
        width: 44px;
        height: 44px;
        background-size: 100% 100%;
        position: fixed;
        bottom: 5%;
        right: 6px;
        z-index: 111;
    }

    #audio-play .on {
        background: url('assets/img/music_on.png') no-repeat 0 0;
        -webkit-animation: rotating 1.2s linear infinite;
        animation: rotating 1.2s linear infinite;
    }

    #audio-play .off {
        background: url('assets/img/music_off.png') no-repeat 0 0
    }

    @-webkit-keyframes rotating {
        from {
            -webkit-transform: rotate(0);
            -moz-transform: rotate(0);
            -ms-transform: rotate(0);
            -o-transform: rotate(0);
            transform: rotate(0)
        }
        to {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg)
        }
    }

    @keyframes rotating {
        from {
            -webkit-transform: rotate(0);
            -moz-transform: rotate(0);
            -ms-transform: rotate(0);
            -o-transform: rotate(0);
            transform: rotate(0)
        }
        to {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg)
        }
    }


    @media only screen and (max-width : 375px) {
        .hotxy::-webkit-scrollbar {
            display: none !important;
        }
    }
    ::-webkit-scrollbar-thumb {

        background-color: #b0b0b0;
    }


    .search{
        text-align: left;
    }
    .search[placeholder]{
        font-size: 0.65rem;
    }

    .display-row {
        display: flex;
        flex-direction: row;
    }

    .display-column {
        display: flex;
        flex-direction: column;
    }



    .justify-center {
        justify-content: center;
    }

    .justify-between {
        justify-content: space-between;
    }
    .justify-around {
        justify-content: space-around;
    }

    .flex-wrap {
        flex-wrap: wrap;

    }
    .flex-nowrap{
        flex-wrap: nowrap;
    }
    .align-center {
        align-items: center;
    }
    .hotxy {
        position: relative;
    }
    .hotxy .hotxy-item{
        font-size: 0.62rem;
        display: inline-block;
        width: 20%;
        text-align: center;
        margin-bottom: 10px;

    }
    .hotxy .hotxy-item-index{
        border-bottom: 3px solid #ff8000;
        font-weight: 700;

    }

    .tab-top font{
        font-size: 0.65rem;

    }
    .tab-top-l-icon{
        color: #f4b538;
        font-size: 0.65rem
    }
    .tab-top-r-icon{
        color: #000;
        font-size: 0.65rem;
        font-weight: 800;
    }
    .tab-top-r{
        border-left: 1px solid #dddddd;
        padding-left: 10px;
    }
    .tab-bottom{
         width: 100%;
    padding: 0.8rem 0rem;
    font-size: 0.6rem;
    position: absolute;
    top: 2.0rem;
    left: 0;
    z-index: 99999;
    background: #fff;
    box-shadow: 0px 3px 5px #e2dfdf;
    }
    .tab-bottom-none{
        display:none;
    }
    .tab-bottom-item{
        padding: 0.3rem 0.8rem;
        background: #ebebeb;
        border-radius: 50px;
        margin-top: 5px;
        margin-left: 5px;

    }
    .tab-bottom-item-index{

        background: #1195da;
        color: #fff;

    }    
    .layui-layer-title {
        padding: 0 80px 0 20px;
        height: 42px;
        line-height: 42px;
        border-bottom: 0px solid #fff1dc;
        font-size: 14px;
        color: #333;
        overflow: hidden;
        background-color: #fff1dc;
        border-radius: 2px !important;
    }
    .layui-layer-btn .layui-layer-btn0 {
            border-color: #fff1dc;
        background-color: #fff1dc;
        color: #333;
        font-size: 13px;
        border-radius: 10px !important;
    }
    .tab-top {

        position: relative;
        height: 1.8rem;
        width: calc(100% - 0.8rem);
        padding: 0  0.5rem;
        margin: 0 auto;

        border: 1px solid #dddddd;
        background: #ffffff;
        /*filter: drop-shadow(0 0 5px rgba(0, 0, 0, .1));*/
        overflow: visible;
        border-radius: 10px;

    }
    .tab-top::before{

        content: "";
        position: absolute;
        width: 0;
        height: 0;
        top: -20px;
        left: 25%;
        border: 10px solid transparent;
        border-bottom-color: #dddddd;
        z-index: 9;
    }
    .tab-top::after {
        position: absolute;
        top: -19px;
        left: 25%;
        border: 10px solid transparent;
    }
.xz {
    background-color: #3399ff;
    color: white !important;
    border-radius: 5px;
}
.tab_con > ul > li.layui-this{
    background: linear-gradient(to right, #73b891, #53bec5);
    color: #fff;
    border-radius: 6px;
    text-align: center;
}
#audio-play #audio-btn{width: 44px;height: 44px; background-size: 100% 100%;position:fixed;bottom:5%;right:6px;z-index:111;}
#audio-play .on{background: url('assets/img/music_on.png') no-repeat 0 0;-webkit-animation: rotating 1.2s linear infinite;animation: rotating 1.2s linear infinite;}
#audio-play .off{background:url('assets/img/music_off.png') no-repeat 0 0}
@-webkit-keyframes rotating{from{-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-moz-transform:rotate(360deg);-ms-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes rotating{from{-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-moz-transform:rotate(360deg);-ms-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}
</style>

<style>
    body{
        max-width:550px;
        margin:0 auto;
      overflow: auto;height: auto !important;
    }
    .container {
        margin:10px 0px;
  width: 80%;
  text-align: center;
}

.progress {
  padding: 0px;
  background: rgba(0, 0, 0, 0.25);
  border-radius: 6px;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.25), 0 1px rgba(255, 255, 255, 0.08);
}

.progress-bar {
  height: 12px;
  background-color: #ee303c;
  border-radius: 4px;
  transition: 0.4s linear;
  transition-property: width, background-color;
}

.progress-striped .progress-bar {
  background-color: #FCBC51;
  background-image: linear-gradient(45deg, #fca311 25%, transparent 25%, transparent 50%, #fca311 50%, #fca311 75%, transparent 75%, transparent);
  animation: progressAnimationStrike 2s;
}

@keyframes progressAnimationStrike {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}
.progress2 {
  padding: 6px;
  border-radius: 30px;
  background: rgba(0, 0, 0, 0.25);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.25), 0 1px rgba(255, 255, 255, 0.08);
}

.progress-bar2 {
  height: 18px;
  border-radius: 30px;
  background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.05));
  transition: 0.4s linear;
  transition-property: width, background-color;
}

.progress-moved .progress-bar2 {
  width: 85%;
  background-color: #EF476F;
  animation: progressAnimation 6s;
}

@keyframes progressAnimation {
  0% {
    width: 5%;
    background-color: #F9BCCA;
  }
  100% {
    width: 85%;
    background-color: #EF476F;
  }
}
.progress-bar3 {
  height: 18px;
  border-radius: 4px;
  background-image: linear-gradient(to right, #4cd964, #5ac8fa, #007aff, #7DC8E8, #5856d6, #ff2d55);
  transition: 0.4s linear;
  transition-property: width, background-color;
}

.progress-infinite .progress-bar3 {
  width: 100%;
  background-image: linear-gradient(to right, #4cd964, #5ac8fa, #007aff, #7DC8E8, #5856d6, #ff2d55);
  animation: colorAnimation 1s infinite;
}

@keyframes colorAnimation {
  0% {
    background-image: linear-gradient(to right, #4cd964, #5ac8fa, #007aff, #7DC8E8, #5856d6, #ff2d55);
  }
  20% {
    background-image: linear-gradient(to right, #5ac8fa, #007aff, #7DC8E8, #5856d6, #ff2d55, #4cd964);
  }
  40% {
    background-image: linear-gradient(to right, #007aff, #7DC8E8, #5856d6, #ff2d55, #4cd964, #5ac8fa);
  }
  60% {
    background-image: linear-gradient(to right, #7DC8E8, #5856d6, #ff2d55, #4cd964, #5ac8fa, #007aff);
  }
  100% {
    background-image: linear-gradient(to right, #5856d6, #ff2d55, #4cd964, #5ac8fa, #007aff, #7DC8E8);
  }
}
    
    
    .top{
      background-color: #<?php echo $conf['rgb01']; ?>;
      width: 100%;
      max-width: 550px;
      padding-bottom:10px;
      }
      .home{
              text-align: center;
    line-height: 32px;
        height: 32px;
        width: 32px;
        border-radius: 50%;
        background-color: #fff;
        position: fixed;
        top: 10px;
        margin-left: 10px;
        z-index: 9999;
      }
      .toptitle{
      font-weight:600;
      color:#fff;
      text-align: center;
      height: 56px;
      line-height: 56px;
      }
      .classbox{
        margin-top: 5px;
        display: flex;
        justify-content: space-around;
        color: #fff;
        margin-bottom: 5px;
      }
      .classtitle{
        font-size: 13px;
        text-align: center;
      }
      .classtime{
        margin-top: 7px;
        font-size: 11px;
        text-align: center;
      }
      .clssbox2{
        padding: 10px;
        display: flex;
    flex-direction: column;
      }
      .classacvt{
        border-radius: 10px;
        background-color: rgba(0,0,0,.2);
      }
      .top2{
      
      }
      .top2 img{
          height:22px;
      }
      .splist{
          background-color: #f2f2f2;
      }
      .spbox{
          margin:10px 0px;
          padding:10px;
          width:100%;
          background-color: #fff;
          display: flex;
      }
      .spimg{
      border-radius: 10px;
      width:40%;
      height:100px;
   background-size:100% 100% !important;
      }
      .xxlist{
          width:100%;
          margin-left:7px;
            display: flex;
            flex-direction: column;
    align-items: flex-start;
      }
      .sptitle{
              font-size: 13px;
    font-weight: 600;
    line-height: 17px;
      }
      .spprice{
              color: #ff8000;
    font-weight: 800;
    font-size: 13px;
    margin-top: 5px;
      }
      .spprice2{
          color: rgb(153, 153, 153);
    font-size: 12px;
      }
      .buys{
      padding: 5px 15px;
    font-size: 11px;
    text-align: center;
    background-color: #<?php echo $conf['rgb01']; ?>;
    border-radius: 50px;
    color: #fff;
        
      }
      .buyss{
              background: rgb(153, 153, 153);
      }
           .rob_st {
    width: 82px;
    height: 29px;
    position: absolute;
    bottom: 0px;
    right: 0px;
}
</style>
<body>
    <div class="top">
        <a href="./" class="home">
            <i class="layui-icon layui-icon-return"></i>
        </a>
        <div class="toptitle">
            <a href="" style="color: #ffffff;">今日更新</a>
        </div>
            <div class="classbox">
                        <div id="c1" class="clssbox2 classacvt" onclick="get_goods('today','today',1)">
                <span class="classtitle"><?php echo date('Y-m-d')?></span>
               <span class="classtime" style="font-size:12px;">今天 
                </span>

            </div>
           
                       <div id="c2" class="clssbox2 " onclick="get_goods('yesterday','yesterday',2)">
                <span class="classtitle"><?php echo date('Y-m-d', strtotime('-1 day'))?></span>
                <span class="classtime" style="font-size:12px;">昨天 
               </span>
            </div>
           
                       <div id="c3" class="clssbox2 " onclick="get_goods('daybeforeyesterday','daybeforeyesterday',3)">
                <span class="classtitle"><?php echo date('Y-m-d', strtotime('-2 day'))?></span>
                <span class="classtime" style="font-size:12px;">前天 
                </span>
            </div>
           
                   </div>
      
    </div>
    <div class="top2">
      
       </div>

                           <section style="display:none;height: 40px;line-height: 1.6rem; background: #fff; display: flex;justify-content: space-between; align-items: center;" class="show_class ">
                 <div style="width:56%"><img src="./assets/img/new2.png" style="height:22px"></div>
                 
                    <section style="display: inline-block;" class="">

                        <!--section class="135brush" data-brushtype="text" style="clear:both;margin:-18px 0px;color:#333;border-radius: 6px;padding:0px .5em;letter-spacing: 1.5px; ">
                            <span style="color: #f79646;">
                                <strong>
                                                                        <span style="color:#7d7c7a;font-size: 12px;">
                                        <span style="color: #767676;"><strong><span style="font-size: 15px;">
                                         <span class="catname_show">正在获取...</span></span>
                                        </span></strong></span>
                                    </span>
                                </strong>
                            </span>
                        </section-->

                    </section>
                  
                    <span class="text" style="padding:0 20px">
                        共计<span id="total">0</span>件商品
                        
                    </span>
                </section>
                
                
                  <div class="fui-goods-group" style="background: #f3f3f3;" id="goods-list-container">
                    <div class="flow_load"><div id="goods_list"></div></div>
                    <div class="footer" style="width:100%; margin-top:0.2rem;margin-bottom:1.2rem;display: block;">
                        <ul>
                            <li>© <?php echo $hometitle?>. All rights reserved.</li>
                        </ul>
<p style="text-align: center">
<b><script type="text/javascript">
var now=(new Date()).getHours();
if(now>0&&now<=6){
document.write("经常熬夜对身体不好哟~");
}else if(now>6&&now<=11){
document.write("早上心情好！ 快来买一单~");
}else if(now>11&&now<=14){
document.write("停下手中的工作！ 去吃饭~");
}else if(now>14&&now<=18){
document.write("累了一上午了！ 休息会吧~");
}else{
document.write(" <center> 晚上好！ 欢迎来到本平台~");
}
</script></b></p>
                    </div>
                </div>

        
    </div>
    
                <a id="backToTop" style="position:fixed;right:10px;bottom:10%; z-index:20; display:none;" href="#top">
                    <img style="width:45px;height:45px;border-radius:50px;border: 2px solid #e8e9ec;background-color:#fff" src="/assets/img/xtb/dingbu.png"/>
                </a>
			
        <input type="hidden" name="_cid" value="">
        <input type="hidden" name="_cidname" value="">
        <input type="hidden" name="_curr_time" value="<?php echo time(); ?>">
        <input type="hidden" name="_template_virtualdata" value="1">
		<input type="hidden" name="_template_showsales" value="1">
        <input type="hidden" name="_sort_type" value="">
        <input type="hidden" name="_sort" value="">
  
    	<script src="https://libs.baidu.com/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdn.staticfile.org/layui/2.5.7/layui.all.js"></script>
<script src="//cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="//cdn.staticfile.org/Swiper/6.4.5/swiper-bundle.min.js"></script>
<script src="assets/store/js/layui.flow.js"></script>
<script type="text/javascript">
var backToTop = document.getElementById('backToTop');
window.onscroll = function() {
    var scrollDistance = window.pageYOffset || document.documentElement.scrollTop;
    var threshold = 300; 
    if (scrollDistance > threshold) {
        backToTop.style.display = 'block';
    } else {
        backToTop.style.display = 'none';
    }
};
</script>
<script>
var _0xodG='jsjiami.com.v7';function _0x2cb6(){var _0xf3561a=(function(){return[_0xodG,'OKLxjJnsGVjnYFiVRQawmFRiJNd.OcpDoCmBu.v7==','eG0shq','CSk0W6PDEG','CSk8W69s','u8kYyeldRW','lZVcNSo0','W7VcTMmDWPa','B8kLW6tdJ8oFWRqdA1ddV8oiW5dcGmkAW4qZeSkwWQVdIYy','mqrE','fqtcNCoPWPu','fmkdh8kfWORdOCooW7tdS8oPsN0giSoVWOFcJSopf0jJWOVcGcJcKCoaW61OtSk4qJVcGCoat0vaWP/dTsnWWRbfW7TXga','F8kTW7nCC8oEW4K','W5OnjCktW5Cy','W5ObWOxcTG','W4CuWONcPW8','6i+45y6N5PEu5O676lsv5PsV','WRJcKtRcTvS','WPSXbZxdKa','WPZdOKpdOW','W7yMcmkuW4K','geankG','aCooW6FcRsG','W77cPfqr','vCk0W5tcM8ky','W4tcOKZdUa','WPDNF8oTW5y','ESkHW7lcN8k1','5ysiWPv+W5VdVW','pcLNW48x','gcVcPSkWW7ZdUaRcUGlcJ8kJfYhdV8oUaWLoW4mWWQhcIbimq8k4W6rCjcNcQSk4CJhdJZTpW6yqBhpdRSoUtd93eaRdMG3cQ2NcIWy','ENO2uXtcQqxdHW','dapdKCkBW7S','yITKfx/dULtdISkqdYZdTIu','W6WMESoehG','W4VcGwldTNi','W6BcUSkEiYq','W4RcQ8kmeqS','W4CDvSoziW','vSomgJKc','W4FcRSk1gXm','DtJcUCk8WOa','tCkcW6lcV8kd','WRZdRI7cUvZcKmkmA3a','W5abWOtcTJK','xM4AeafFW6vN','W7pcI8oUAdS','W4KSb8kVW5C','y8kGWRvDW5G','EdNcKSkBWPC','o8kvW4hdTCo6','rConedK','W6JcS1xcVmkhWOW','tCoOC8oZW7m','WQBcMeFdO2VdI18cWQaa','jCodb8oMWQu','WROLW7bhDG','FerjWRVcIG','xmoPDSotW4P/vmoj','W5BcLCk1pSkW','WRS7W5r6Dxr5','rmkeWO53','aeuinG','W5CpWOZcTG','ECk7W70','b8kEWOddJfhcMfWlgCofWPO','oIDGW6ibWQ0YjW','WOWdbcNdSq','p8k2W6RdLmoE','ahzaa28','WQtdHuldSSkG','cCosqZ4XWOO/cSoNqSkapqe8ySoIdMNcTeHEwNBdPSkxD8k9ymoHtCkuWRtdU8kWW59JW4ZdHSooW57dISkNWP8DW6D4ASobdSkcW53dGmk1W5SpoCkuvbldIoweKUI1S+wxNEwrKmkAk8oclW','B8kdm8kPWPC','amkvW47dL8ou','5lIx5zEl5zotWQZcIxHiW5tdNaC','W5lcNmkGcmkVWRyzbKr4ptFdPh0','p1KXybG','tKKHjq4','yguUDqhdUxyvWRldVxO','WOfSCCocW7ZdJYib','W6/cRmoJFcvV','W6S0W5rLEgPbW79xy2iEW74','WO8vASoctG','W6RcRCoJrHG','v8kxWPRdN2FcGXaC','a8k3W6JdKSo1','WQVdHu7dHSkT','W6JcOe0FWO1JumkhiLpcSq','W4tcQMdcNSkB','imoSW6FcMZ4','hMvnna','vCkFuL3dRq','mrVcS8otWPO','W4qgqCofqmo/W6S','WQBdJ17dPSkZ','W7hcJ2pcO8kx','CmkeW4dcOSk1','wLaJmYK','ls8aprK','vueWfW8','WPryzmofW4y','W5JcUXNcPSoMW5dcRsHvqSoOWQi','pmokW4hcTdq','WReXW7H6Eq','W6ZcH0mwWRy','ySk2W7hdH8oC','zszYW7nZW6/cNq','WOZdKfxdGmks','bwOxvq8','oCoOW67cLWi','hab4','zmoldH8q','icZcQ8ooWQC','fW7cImoPWQK','pKuuyb0','hY5TW4mP','cXvGW6y','yHiyW4HbadX1dY7dL8kaW4OfkmkDpSoGWPqdp8kEz0xcGq0MW53VVASMW5tdVZrFWRj4W7vrAmktW4jACJTBW67cMmkpWPpdQSkTwXikWPxcP8onfCkVESkDi3nFer/cPCo3oCoyWOSFBCkyWPe','wmkzWOzWW5u','W5ZcHsBcHGy','W7y+r8oipmobxmotnHOXWRX4W4a','W5abWPZcSG','fCotWQHbW77dP3Sv','WPSJhG','W45jlSoZWRy','gSoAW4RcLG','WPLQvSoXW7u','hNjljeG','wCkmW6PPEG','W4xcSmojvGK','f8o1FsBcOW','W5dcUSoLxty','gdNcVmkSWRldVHJcOaNcISk0ssldTCo7fbbdW44','WQeQattdPa','E8oqbGyV','uCoHwSogW5u','vCk/zNZdJSo+W6ZdRW','WQVcIZtcSfS','5QY/5z276i2g5y2v','amoyWRHJW74','WPCUAmoj','eubmee4','W7lcR04BWQW','v8kxWPRdNW','WQm3pJ/dQW','x2myccHo','W6RcS0/cJ8kB','DSkKW5/cOSko','W70HWQpcVcy','amoqW7/cTrC','FmoWmr0r','sWGya1tdU3ZcMZ3dOfVdJHPLC8o+W4NcTSoYoK1veg7dHSk3WRxdQCock8olvCoGWOpdTCoeqsNcVw9oD3vUW65cWOrGW4mYW7FdMb5PWQn3iXunWRFdJhftuqqIW5FcIu5FW7NdPcWWWRybBqFcJuBcOv3cQmkwlmkXt2nyWOvpW4bGW7RdQgFcVa','y0PcWQJcIa','W7RcMvFdGCo4','D8kgnCocWRFcGG','WO81xCoOqG','kSonnCoOWQ3dNCktW4S','wujlWQxdPSk8dCkw','W6ZcM0tdLwG','WPOTBSoxsW','6kYx6l6B5ywW5yEY6zA+6k2J6l6k6kc+5PYP6kYg','jmopnW','tSkcWPX9W6q','fmoaW5tcLIK','xItcT8k8','sSobEmorW4W','W4dcVe3dP2G','WOhdUCo6WQC/','b8okb8oNWQW','vgDyixv6WQyovSkYW7JdU8og','oJTUW6e7','W6VcLupdTq','W7/cUdlcKbNdRmkmssqAW5hdKSoiWQP8WP7dNColhNO','tSkBy1xdKW','W6RcUmoT','u8kgWQ/dGeW','W57cOmoyzIK','o8kiW6tcM8kMW5LaxgZdRrnXW7VdQqGKqvq','aaXCW58B','W6S5wSoy','W4hcJZRcRbq','W6dcQupcJCkJ','W6/cSCoUzG','W73cMCkkbYVdGmo6BdpdVZu','WP89q8o7Ba','W5b0i8o9WQNdKMmoW7/cMdlcTdJdKxebACoapW','W4NcRuJdRmojfhZdLSkaW5hdOWRcIeVcNmkeWP/dNColWRm','t8ksWPHzW4e','EG9XW4Ts','xNiueZS','uCksWQZdON8','ACkdy1/dVW','wu5oWO7cVa','jCo+WRPSW4i','tmoZzaNdI1HOhmoygSo5W4NcQmo+WQxdJSkWW4q/W40uWPH/W79ZWOC7i8kDcG8Twra1WO/dVaeJnCooacGelSoVWPbxdMBdVcfeWRmBW6P9WQ8rW4afWQlcKbS1hdDgW55UW7dcOwtcGLmoW5PKjqJcI3ZdTHrakY7dPCoezSoKWRRdLmorg8kNfCkhDComW5ldUuTUhuLKW7ldSa/dGZNdO2brW595o8oVtCoWxf4aWQLXvaFdMmolWPBcMxZcGuFdT8kFjIT/W7GQt3G8W7mNdIxcS8ojWPFcKCkqW7xcHcC3WR7cQG8XhWVdNg/dGSoKwNvVW6ZdTSkzaZClr8kiWPb+wYddJtblW659fsTYW4pdQahdVSkNW57cPmodzCk1aW','hXRcVCoeWR8','hmkCuqi1aCo5v1eAvCkzWQXwdCo9D3yeWOdcGSk0W4ddT8oPfMW0gSoNWORcKCkNWO/dIgRdJmofaceyWPbtWQddMmkvy8kHkgpcHI5CWPTJa09RWRRdUdBcO3FcRCkxb8kAWPFdVb/dKN7dNG','qmkhWQhdGNe','W4tcQCoNsrG','imoFaCoJWQu','mHfWW7Wy','WP4Qhs4','cSoJhCoKWPG','z2OO','drKZpa0','gZbcvwOBWRr5W5aQAXzR','xmopbd03WPW','xSo0BaVcHvPPgmo0gSkSWOtcRW','W7tcG8ojvIO','WQf9xCoSW4q','l8kUW6tdK8oE','W43cI3RdICoE','nGBcH8oUWR4','fmkpWOzLWO7dV04Srh7cM8o+WPaGW50qwuFcUmoupqycWQjmWQFcMv03WQfbxmkbW7tdN8oTpdWnWQH9W7udWQhcLw8g','i0vagNi','W7ugWQtcMrO','W4mjWOZcPWi','W7VcOuqZWPDNymky','x2mgdIro','xCkNW5rDCG','gc7cSSkTWR/dTWBcQt/cNCk5vhG','CWldLmk0W77dUxSDtSoGWQGHnq','peOnaYe','kXfDW4L0hJv+rG','dGmEfci','xmkhW4TgAa','W5q2iSkFW44','CSkjWP/dUuK','W6JcU8kthZ4','W7NcLCo1vJy','W6NcVeBdTvq','rSobesGGWP0','W6JcHKpcG8kO','tSoLFCoNW7LQrSoD','sePWWRZcOa','WPtdOsZcHce','W7BcRfme','nt3cGCo2WO0/W7jjDSknrZxdRwKAWO14WObXWPhdJ8kyWOpcGc7cHKBdUmk0qSoLW7vR','W4SLm8kbW6G','W73cVvy','kr3cPmoHWQS','fwKfsZS','rCkpWOxdJvBcKW','jr3cQ8omWRu','W6hcThVdV8oF','yhZcKmk9','oYPIW7OOWRWqlfRcKWG','W5XSFmo3WRddJt0tWR/cLZ7dQMJdIcaFpSoekcpdHCkjmtJdK8kBWPRcH8otW7rwfmkYWPLTpmkQWRnqbqKkW5CJmSo0W7BdJCkcW7W','AdiYgq','xmomeZGXWQG9dSk3bCoEdq46Dmk2tYFcTYu','oGzzW5Gu','WQddH8oTWPKy','E388WQDQW6KJa3dcHsea','C3aZFXNdUa','W44YWOVcIsq','WRRdRGldR8ozW57cGSo7WOJdSSoAimk9','W6VcSmoLzsq','WR7dJSorwdtdPSoHzGhdMW','W5m1wSoncq','gwy5kt4','WOuRfJW','WQnfhCotWO5po8kKWO5g','aezmbfq','bSoiW4K','vmoJDSo1W55rqq','WRCNosddRa'].concat((function(){return['W63cVv7cSSkNWOC','a8o/yGJcTe9LgG','hc1TW60z','W4BcLCkAbSk1','mceWeZe','hCoyWQzhW6u','uSkNWO1wW4O','W54PWPJcNI4','pCkWW7hdUmoz','oGD7W7SM','zKCIhsy','smkoAqz0','aSo8WQTbW5m','tMKraG','nw0JqIxcRG','W74Zq8oupSo/D8oEpHjPWRL7','n2mlja8','e8o7BaZcMfPNc8oF','W65RkCouWOe','kcxcGCovWPu','WPxcMH7cL3K','a8obW4RcIcFcMLW','WQhdRdJcSYu','W4apWPZcSGy','sCkmWPi','D8onomoDW6hdLCkeWOxcGCkyWPldQCojW4iVDfrxfqaQusJcRmkcW7TPcG','WRRdP3RdSmkc','xxu3Ebi','mJDYW7SK','WRBdTXxcJIm','FCksfSkGWRa','tmoqeImS','WR/cUSoTCd9OWP3dQbS','WQJcPftcImkAWOZdISod','pdr9W5b8','u8oJBb3cN1r0eq','WRtdQsxcLb3cGSkqAG','WP4Sx8oeAW','W5FcUYBcRJC','WRacwSotyG','FYbTW7zUW5NcLmoHyZZdRYW2W4lcUCkGsa','qSkAWPtdINRdHxddTwqjfmkZ','pCkmW53dQmou','iNG9nY4','WQtcQb/cS0K','WPbiW4/dSbldHKBcPCoEW67dUKldNGuoeZydtSo0dmobqmoBzxu3ra','W7LpeCoc','qCkkgSkUWOK','W7Thea','W4/cTK3cTmkWWOtcJYCkvSo5WQPNFa','D8onomoDW6hdN8kmW5NdKmkmW4dcPmoeW5WrF1GgxW','W7lcVLVcSCkQ','i38FAI0','W63cQCk6b8kA','WOq6prRdRG','uvnUWP/cPW','oheLyGq','W5ydpmkc','WOvNrCoGW70','FSkDWOvcW4e','swmgba','aIfSW6a1','W4RcJSogzW4','u8kgWOldOeO','qCkCxdD5e8o+xq','yc9X','odlcHCoI','avC8DH0','orddIa','kSk5W7jfpCoyW51woCkjzL3dT8oGW4Cmi38LCSkYWOtcVfucEa8uW6jzWPe2WOnczbfgW5xdKqtdQCk9vCkTW4NcJ0iNWPmaWRBdMMH/qCoeWOf0j1RcKSk4eSovW5OTWQRdTctcVxZcT8kDWRdcQdtdT8oTvLXtW6uSW5GDW4hcNmokWR3cMSkgW6DromozW4CbW5FdLW','W6JcJNZdNSoT','W5ZcJNuEWQ8','kaFdHSkuW7m','W5i1xSofoq','D8kgn8oeWQ/dImoE5yEj5P6Q','W57cUbRcPmk9WQBcOYb0yG','q0LlWRVcOSkWgG','W5WdjCkg','pGPNW7O1','5yQg6l6R5lIP','WPVdTmoDWOya','yCkLCvVdQq','oSo6W4hcMYu','bSkFWPv0W5C','bKGf','vCkIzwtdGG','WRJdUspcLH7dKSkww2ymWPJdOSozWQy3WOddLCofd1iXzSkEtCobW4VdISogWRm8l11YDmo7W5a','atDeW5m2','ySkQW6tdLmodWR4','W4PRB8oEDmosWOlKUR/LLPhLKjC','W6dcKtxcSXG','WPO4W75VCa','x2myccHoW4DSW5CkCq','FuPLWQRcGa','W7/cKmkgeq','vhDroMXeWQGhAmkYW6m','qSkJDq3cM3zMcW','qMihwZ4','qCkLnuFdNaW0mCoDj8kLWP/cNq','5yQq6l2C5lIj','WQy1W65Ruq','gCobrtdcIa','DwbRW7WOW6C','nrxcImoiWOa','gc7cSSkTWR/dTWBcQt/cJq','iSohiCoEWRxdP8koW5NdJSkAW4ddMCooW5Gurq','WQxcUf/cOCkhWORdL8kxW5ddN8ouoSkmkwZdQLa9W4T9WQ1LWOBcKa','W5/cHtVcSbC','WQe9W4T/AejWW61FzY0IW6xdIfCZbW','WR0wjc3dOq','WOhdN8ooWQig','hxCPutG','eNbuoq','WQddOMJdUCka','baKfir3dPw0','ECkNjSkiWPG','WRHTC8oXW6C','gw1D','WQ3dNmkibJ7dICoqyZNcSwtcGJldKmkkWOS','EI7cT8kvWQS','W5m4rmoqkG','A8klcSkoWRi','W7VcHSkqbHG','pq5xW4Hq','AuiIiCo1','W5GpWO8','W6NcRKRdUK8','W6z8W5PGFweWW7XACI8CW7xdKXGKmZjMW7iMAZZdVq','W7JcUmo1Ca','W7PefCoLWOG','W7VdPs7cOWNcMG','jCoRn8ohWQG','FYbTW7zUW5NcLmoHyZZdRYW2W4lcUCkGsJ0KW7PnWQW','iCktW6xdOCov','smotWQv0WRldTxWFWPfPDf3cRgeFngZdI8kOp8kwkmkzWPqvbXlcRSk0wmk+x0WyCaldJCkzC8k8W4tcNsy6','rKbi','EeeVcG0','dGzEW6qw','W6nheCoc','CmkYWQVdG8oxWQzDDatcRSorWPtcJCkfW5GUemkAW6FcJICFhaGdBc0HcqZcLmoBW6e+qmoSWR7cP8kiW4DcaZ47Amk6aIXoW6HCpLu2y0DcWPPNWQBcLSkylmooF1nrpvZdSNqpW47dUtiLaGlVVkFdVCobW4vZW7GffG','oSkmW7/dR8oT','W5JcL1xcKSkF','qmorbJ8eWPq2aCkU','brxcKmo1WPC','W4NcRuJdRmojfhZdLSkaW5hdOWRcN0FcLCkAWPldKCoAWOVcVZZcRCoAWQNdSKOFdCo4jW','vmktWPtdKq','WOddKL/dNCk7','6i+h5y2b5Pw95OYr6lwU5PEn','W4XlgmoSWRO','W6lcV1xcUCodWOJdGSoh','gdzjW786','eSoQW7BcQYW','ng55W6jUW6pdL8oUBZtcT05N','WQ5be8oiWOrDcCkTWRHwAW','tSoLFCoGW49Zqa','CZLMW6y3WRS/jq','W7OFDSoFgq','lCoVi8oLWOu','CCk0nSkzWP0','WOrTy8oOW7pdIWeBWRtcGw/cMM3dMs8s','W4CiWOFcPa','kmofpSoyWQq','ir7dTmkgW54','W48UfCkHW4i','e8o4yHtcGL4','WOqOt8owxq','WOddV1NcUCozlMBdLSoaW5FcTZhdLGa','W5lcUI3cRca','c8kiWOnYW4pcSfnTrq','W7BcUuhdMmoi','WP3dR0hdU8kIWOdcUcPgrSoJ','ECokecaN','BSk/xMhdHa','W57cJ8kebCkN','uCkeWObYW6y','CSktW7hcQSkv','bSkeW4xdRmo6','zCk8W7DwBG','W50Nf8kKW7q','WP8YrCoEwq','zemkdCor','bSkcWOX8WPdcQKPR','sMmbiJjoW6LLW5GnqabGpa','WQmBW45WFq','pIGWorm','vstcTW','iGy2lXu','CCkHu3ZdLG','W50oWPJcPH7dS3FcSmowW7pcSZRcHeqAbG0sEmoXhCk0','aGzKW4uP','hZCuiGrcW5bI','W4mRetBcPSotmvm','W4dcSc/cQIe','W7lcS1xcTSk4','g2bDfND6WRGy','WRpdK8kugdZdI8kh','tCoGrCosW4S','WRPMw8onW58','WOHpWONdRq','fmkYW63dUmoV','ECkhW7lcIq','cCoWnCojWQK','iCoGW5pcLH4','jCodW6lcOI8','W4pcQLW','WPnGESo2','WRtcLJJcOhy','WQpcRHFcSfm','rSokdd0SWP40','W5lcIftcNmkx','W4NcRfldNmok','W7VcKCkEgYC','p8kJW5RdSSoE','vfe/jIy','W702oCkiW5m','W6GPBCovpa','t8koWPTwW5ZcPKPPswBcUmo0WQP5','vK5NW6q9WPjw','dMOCfcPjW6HVW5us','FSkuy2FdKW','vCoPvCoGW64','aXHEW54Q','WQ3dHSotWQ4J','a8oJyHZcGa','isPMW7i2WQ0','oCooWQhdI8kUWOW5rMVdPHDTW7tcQqW2vqRdJuVcIcLVyCo4WQLoWQy','kdZcLCoIWOa','W63cICkYfCkx','pdqzdrm','sW4dsW','WPVcISkJjmkZWRygtKH5cZRdGNCYAr98WOO','WRaKW7D5FG','FwCYaSoR','aWD+W4ql','W7ZcISkWosO','wqJcGCk9WQy','F8k7W7fJsG','W5ZcKmknk8kt','rw8raG','W5pcJhhdQSoN','c8khWOzGW4tcOuTJrhK','rbbFoYm/ESk9vG','q8kuwqDMhmoSq1G','EN4YuYxcQWNdLSkPpYy','e1vlWR/cQSkX','W6hcThFcOWNcTCkcC1y','s1iJprK','WOZdM8odWPOE','W43cQL/dPSk3W5JdMwGivmoJWR0/kGKoW5TNemoLWOlcMbOerCoeo1PGWOZcRqNdISkXWOtdRmo7W78acSkSWOJdKmo2W6GbWQldNq','W7OXvmov','W7PFc8oVWPi','dtVcPmooWR4','W7pcUfFdQvO','eWxcR8ofWO0','aKWeic0mwmk7zCoXdG','prlcH8oZWO4','CSkCDWDI','cZhcGSoUWOm','r3uAcq','EHVcKSoiWQytzG3dKCo7f8ksWPVcPsi','W6yWW5P+CNHZW6LTyq','FCkHWObcW6y','x8kXtvxdNW','kXddKmk0','umoRDmoEW5u','nd05eYq'].concat((function(){return['oCo/wa3cQa','W4tcP20','y24Pkmosbte5W6BdK8ke','f0nphN4','zSkVW7jqEa','W7BcGehdS3q','W6O3hCkjW7q','fYpdOSk2W7W','nSo0vaVcGG','W7VcVmo1rsv2WOW','W7lcGmo2DaG','WPZdI2JdMSk9','WOWqtCo/yW','yx4geSoY','W6ZcPdVcSXK','kXfD','bSoBWOPLW5u','AaZdNCouWRyzvrVcG8kRbCoDWPhcUhNcICo6WOhdTK8HWO3cVSkHW5nlgCkL776zyJu0WQSkWRtdGCoFW5zSWRRdNtFcIqFcLSo+WRLaoZlcQZjZlmolAgmZq0f2jCokWOJcMCkyCwtdLCkmW5bDBmkOWQS','devnWR3dQ8k+eCkhfriscbVdKLRdQmodiLZcLaXhiHhdS1yMiCkWW6CzWR1GjWHZW73dL8khWQZdI8kEvSo0CrHvWR9hW5ddTrxcOmoavCoSW5fg','reHa','zCoQxmojW5C','WOHpWOZcUHZcLG','swuqbry','W47cJMhdVNa','C8kcW4NcP8kW','W5qrymohma','q0m0W7CWWP0BD8kBiWuUW6xcU8o8W53dIaddNb1etahdQNvxF8kkdtdcO8kddt/cKa','W7/cLmouyI0','xmo+ASoFW4C','tWPlW4Xp','A3mTwYi','bI98W4Cv','C8kdW4/cVCk0','WPuTBq','WPVcMSk1oCkTWRizbNv/fYhdMG','baqEbr3dPw8','tCo/E8oZW4m','W67cMeJcV8k7','acKzgH8','uSk/ya','WPFdS0ddUSk8','WOvRySofW7S','xYdcTmkPWQpdUq','gq5MW6a','W6BcQ8o4rZG','qmkVWRzqW78','rmktW49sFG','jaH5W547','W4ehj8knW7a','w8olv8oiW5q','f24DodG','u25tWR/cMW','W7y6WQFcUr0','DmkjW6ZcRCkH','emowWRHJ','W7VcHfyaWOW','WQC5W7DdvW','W5xcMmokFGa','pZpdJ8k3W6q','oJtdISkdW7G','BSkdWOHkW50','mSoAWR5iW58','W53cUu/dThq','m8oAW53cUqO','WO7dVLJdPG','WQhcMSklbYRdUSovBZpdQa','bqKbgrxdQ23cSsxdPblcIq','W4pcMmk4','WO7dRKJdL8k4WOtcIdu','W4OLkCkrECokW53dPSkKW6ThlmkmESkldSkzWOdcSmkBECo6W5xdJwaaBCkHy0eaW5DICq','ot1MW7y7','mSogpSokWPC','CCk4W68','v8kxWPRdMgFcLHiphmosWOy','W7/cO8ovsb4','WPBdS8oqWP85','yX3cGmk2WOS','rNDjnhu7WQGhAmkYW6pcQCkt','W7qcySoelq','zK7dHCkxW7yuBdhdICoGda','ve0qjaK','d8o0jhpdI8oXW7JdR8oxWQG1WPFcVZ5MWQRdG8ocWPLKWOjiESklEc41mSkuC8ocoxmlzq','gq0Cea','p8ogW6lcICkIWOnlxg/dSWz3W78','umkwWPJdJq','iSoGWOT0W5a','W53cUmk+lY0','W4hcKmkW','eIeRldi','pdNdKmk7W6G','W6iehCkqW7e','s8kqWOpdRLy','WOmCw8oaBa','bcfYW7nY','WRtcTLCzWOTJyCogie/cReOIWOiqrNO','W53cJxtdMK0','mYSGjSoqav87W6BdJCksmZq','pWzCW7HzgcnJ','ztHqW7Pm','WQCEwSoevq','hHXvW4iD','mdZcLG','zSodbsW3WPO','D2OGiSoTdG','WQxdS1xcO8kgWOZdGmkyWPNdMCopmmkzogpdRruHW5a6WRLOW5y','W4hcMehdMvi','W57dQ2RdTIKBWP/dT8o5WPtcNMu','vSorea','WOlcUJtcOq','aCouWOzqW5u','DSkvtKtdSW','W53cJCk5iq','W5iRiCkQW7W','tH5ZW4Ld','j2Ocira','W6L1kSosWQW','W4DvhSooWRu','rbj8W7SRWQmlAmohCHe','omo6gCoVWRu','W5D/gSoEWQq','eM1Dma','W4nVbmooWOy','otNcQmoFWQK','WOiRW4Tozq','yqxdHCkYW4/cT3KCsG','vmoIEmovW5e','qmkQWOPCW74','WQZdHcJcGX8','ySkxtaz4','WRtdGCo0WRKn','xmkcWOS','WOBdNdJcHXa','EgGRkCkjeX0NW7m','jq5JW50w','W740u8o+jmo7qCob','cWvWW6a1WPen','lsqGlSosxG','zeSKwty','EwiGiG','W5e8i8k3WQhdHaivWP/cVfy','s8keWOb4W5NcPG','CWhcHmk2W7ZcUgSceSkXWRz1ECkKW6nkaGH5W7xdQ8oxgI7dQ8kxeCodwSowEfDXWOldSIKMt1naWORdG8kbW7eAW7xLHRtOT5RPOQNLJQ3cM8kYs8oa','W67cVmoSFJP+WQRdPrHWWPW','WPCGBCoYDSohW4/dPG','a2aadNnfW6v2W5qyCa','zxWujSos','WOVcTdBcOg50WOpdNCobWOxcM3rWWPWGWOG','xWNcISk1WRS','oSoAW4FcKrS','WQtdPhRdLvNdG8k3zZ4wWOm','W7JcHfFcVCk4','h8kpW6BdJmoE','B8kdW6VcH8kGWOCLxM/dRra','EN4XpIW','dmopWQHrW4S','D1i5ic8','CCk1WPRdUw4','p0akod0','qCkfWPpdPL0','kYnGW7y1W7KNkeNcHr4','rmkDBIDq','B8kkWOddP2S','m0L8hhK','W4VcGf/dONq','ySk6tq1a','W65pga','W47cRColvtW','WRKhW414tq','WRBdV8oDWP07','W63cKmksgG','o8oinSooWRi','WRPUwCo2W5K','WP0GW71ssG','WQFdUsZcGZu','yK1zWOu','W7BcNehdPW','w8kreCkFWPS','ENqUDG','mtHdW6y8','caxdQSkCW4i','iYVcT8oYWOm','shq5aXG','sCkBvXO4e8o9xG','WPtdNGi','aSoyuazWfmkWdbnqv8owWQ5tqSo4A2epWPJcJSk2WOK','zxK0uGu','W4pcRfZdVa','jq9ZW5eZ','W6PEmSoFWRy','hCoAW4i','efX+eK0','W6JcR8oXrYa','rgGfeIPWW6PHW5SCpYzkmrr7','fdhcUSoAWRS','nwekocW','W6HRjSo+WQy','qmkVWOL3W5i','W57dSCoYWQjSWPaWEeNcVb7cTSkfzmknWPtdQ8k6qY4EBxjwW67dKHbdW4JcH+EUKq','CwWQErW','W4RcLK7dTmo6','pZZcNSoOWPab','yqjzW4vG','jNG+sd3cRYFdN8kxlZy','W5BcKmkW','wConba','e8oyWQjLW7xdOW','W5awpmkl','WOhdQ0hdSq','xCosjX4M','pmoHBWBcIG','5lQF5zA/5zcv','BSkyW4PaEW','hMCSgHC','W6FcLCkddq','gSowWQfN','vSkwW7FcNSkf','nt3cLCoMWOeRW7O','smkeW5/cPCkx','WOLRESoVWR3dNt4aWRG','W7xcVYy','wSoqbYG3','cmkLC3NdL8o1W7NcSCkiW78MWOBcPa8/WQxdHmkAWPK','WRnKv8ouW4O','amoIc8oLWQK','WPKvW7X8Aa','W5WNzSoXW7hdGg9oW6pcLd0','gCodsd7cRq','zt5XW6PU','W7uJwmot','W7NcShZcSmkP','W5ueWOZcKaBdIwRcOG','sCkzWPpdPKS','W73cGhiPWPu','b8oFWQn1','lI8Ija','ptDtW4ug','W63cGepdVa','b8o+W6/cRq8','W6FcHMW','W4dcOKCxWQW','imopW4BcIYW','kSopW6NcJWC','v8opWQjDW6BdO3as','bsehnHO','WQhcJ8kqas3dGmollsxdVIFcKsVdKCkkWOmrWRJdTKGNW47cS8oDW51TW5rPESoz','W4xcQmkdjau','AhK6uwVcQqJdKSkfl3JcUXxcQhddQSoEW7DgAmkMoJJdQSoaWOqdW5FdOfBdUuWLzu7cQYHEt8oLaSo1WRtdR2hdKCowxNxdOCkglZL9W7OAbSkSW6GNWOvNxmoXdG19leBdNJ7dO09QW5G/W4RdHmkkW6mhW5rVdq/dHmk6WPDTlcjOn8kWW5DwWR3cJCoQ','ySkOWRNdO2S','guOgixyiA8kN','s1qTuq4','W7VcOIdcPalcHSkxAITXWPJdGmkVlCkWWPyfWONdUCkOW7zMiKJdU8oseSoLWQZcISoWgmodW7mGdG','bJvNW6WQ','FqvxW5rrcN18w3/dHCocW4CEA8kAnSoZWP9CBq','dHf/W7Pf','r8k8zwG','FSoKfG43','asaMnIy','vmogbW4PWPiGha','W5KjrCouga','W5FcLCkOesS','swCbbG','itxcTCogWRS','W6JcH0K','nxjAnLm','WPVdJgddKSkx'];}()));}()));}());_0x2cb6=function(){return _0xf3561a;};return _0x2cb6();};var _0xae6a7=_0x3916;(function(_0x121744,_0x374f7b,_0x3a26c8,_0xf7bc34,_0x44a125,_0xa8948d,_0x2e6125){return _0x121744=_0x121744>>0x1,_0xa8948d='hs',_0x2e6125='hs',function(_0x3892fb,_0x36df64,_0x38077c,_0x4cd8b0,_0x469096){var _0x2541d5=_0x3916;_0x4cd8b0='tfi',_0xa8948d=_0x4cd8b0+_0xa8948d,_0x469096='up',_0x2e6125+=_0x469096,_0xa8948d=_0x38077c(_0xa8948d),_0x2e6125=_0x38077c(_0x2e6125),_0x38077c=0x0;var _0x3fad22=_0x3892fb();while(!![]&&--_0xf7bc34+_0x36df64){try{_0x4cd8b0=-parseInt(_0x2541d5(0x3dc,'qVQ%'))/0x1*(parseInt(_0x2541d5(0x163,'D2UO'))/0x2)+parseInt(_0x2541d5(0x22c,'HakZ'))/0x3*(-parseInt(_0x2541d5(0x30d,'5zi5'))/0x4)+parseInt(_0x2541d5(0x160,'Lu%g'))/0x5+parseInt(_0x2541d5(0x1ce,'T$x)'))/0x6*(parseInt(_0x2541d5(0x3e4,'0gc9'))/0x7)+parseInt(_0x2541d5(0x25f,'%mAI'))/0x8*(parseInt(_0x2541d5(0x303,'opNi'))/0x9)+-parseInt(_0x2541d5(0x3a0,'JxJO'))/0xa+-parseInt(_0x2541d5(0x197,'UV9o'))/0xb*(-parseInt(_0x2541d5(0x1b9,'0gc9'))/0xc);}catch(_0x4e839e){_0x4cd8b0=_0x38077c;}finally{_0x469096=_0x3fad22[_0xa8948d]();if(_0x121744<=_0xf7bc34)_0x38077c?_0x44a125?_0x4cd8b0=_0x469096:_0x44a125=_0x469096:_0x38077c=_0x469096;else{if(_0x38077c==_0x44a125['replace'](/[xOCFGBnudRLYKDJpVQwN=]/g,'')){if(_0x4cd8b0===_0x36df64){_0x3fad22['un'+_0xa8948d](_0x469096);break;}_0x3fad22[_0x2e6125](_0x469096);}}}}}(_0x3a26c8,_0x374f7b,function(_0x2d6afc,_0x47744e,_0x2e5ea8,_0x4179c5,_0x3e973f,_0x3e6aae,_0x4591ef){return _0x47744e='\x73\x70\x6c\x69\x74',_0x2d6afc=arguments[0x0],_0x2d6afc=_0x2d6afc[_0x47744e](''),_0x2e5ea8='\x72\x65\x76\x65\x72\x73\x65',_0x2d6afc=_0x2d6afc[_0x2e5ea8]('\x76'),_0x4179c5='\x6a\x6f\x69\x6e',(0x17861d,_0x2d6afc[_0x4179c5](''));});}(0x18e,0xb9f8b,_0x2cb6,0xc9),_0x2cb6)&&(_0xodG=0xf0c);var template_virtualdata=$(_0xae6a7(0x151,'oHP&'))['val'](),template_showsales=$(_0xae6a7(0x1fe,'VYdb'))[_0xae6a7(0x112,'0S%U')](),curr_time=$('input[name=_curr_time]')[_0xae6a7(0x1af,'2uOU')]();$(function(){var _0x278987=_0xae6a7,_0x51e06a={'IErrg':function(_0x5498bd,_0x136dc0){return _0x5498bd>_0x136dc0;},'FMUvJ':_0x278987(0x24c,'n9NZ'),'jNoOV':_0x278987(0x411,'D2UO'),'yooaV':function(_0x583cc8,_0x391740){return _0x583cc8(_0x391740);},'VvjQq':function(_0x2be932,_0x355020){return _0x2be932(_0x355020);},'ixOCh':'sort','mHBPc':function(_0x552693,_0x317fb2){return _0x552693==_0x317fb2;},'YiHGE':'DESC','ndOOf':_0x278987(0x32f,'4]lE'),'kvPHd':'aqJwz','iiYfP':_0x278987(0x10b,'n9NZ'),'wyZht':function(_0x3584d5,_0x11c2ed){return _0x3584d5(_0x11c2ed);},'sXmjV':function(_0x593ac1,_0xf5950a){return _0x593ac1(_0xf5950a);},'YDVOU':_0x278987(0x22a,'$epu'),'uEMZM':_0x278987(0x1da,'gigD'),'WCknK':function(_0x3919ab){return _0x3919ab();},'Kzicz':function(_0x54c4a2,_0x40e014){return _0x54c4a2!==_0x40e014;},'pDDtT':'LtkGd','LcdLz':function(_0x31be97,_0x5d56de){return _0x31be97+_0x5d56de;},'IDALg':function(_0xb5cdaf,_0x135403){return _0xb5cdaf+_0x135403;},'jyIFQ':_0x278987(0x2c5,'P$4]'),'saQRe':function(_0x27e67b,_0x769d20,_0x59c441){return _0x27e67b(_0x769d20,_0x59c441);},'kfsBo':'.touchslider-viewport','yIiTn':_0x278987(0x24e,'Lu%g'),'ysnAU':function(_0x5ca122,_0x5498fd){return _0x5ca122/_0x5498fd;},'ZfLwI':function(_0x1d0d84,_0x3d96d2){return _0x1d0d84===_0x3d96d2;},'QyFjd':_0x278987(0x1e7,'C*$M'),'hjnkW':_0x278987(0x378,'CdLa'),'iyJJv':function(_0x18cc9e,_0x78cf7c){return _0x18cc9e+_0x78cf7c;},'UwfKN':_0x278987(0x33d,'n9NZ'),'ouwBC':_0x278987(0x2a1,'opNi'),'LempA':'#classtab','WSZWC':_0x278987(0x1e4,'&8fr'),'gGtwc':function(_0x1a24d,_0x2f92ca){return _0x1a24d(_0x2f92ca);},'gbpYH':function(_0x440d41,_0x45e3f0){return _0x440d41!=_0x45e3f0;},'RdOsw':_0x278987(0x3e1,'CdLa'),'EHcww':_0x278987(0x353,'5zi5'),'Apfgk':_0x278987(0x1a7,'hYEw'),'itwjH':_0x278987(0x366,'VYdb'),'ebVyr':_0x278987(0x1ed,'gigD'),'fWAGq':_0x278987(0x35c,'t!Kv'),'ifjPW':function(_0x299739,_0x3c3626){return _0x299739+_0x3c3626;},'KzOno':_0x278987(0x2a2,'ZNd*'),'zryVt':function(_0x2c80c4,_0x105501){return _0x2c80c4(_0x105501);},'XpfXT':'shop_active','AmdKZ':function(_0x17facf,_0x2c9df1){return _0x17facf(_0x2c9df1);},'QimRU':_0x278987(0x3f7,'t!Kv'),'nBfli':function(_0x1f5720,_0x126c12){return _0x1f5720(_0x126c12);},'qaVkw':_0x278987(0x338,'HakZ'),'puBUV':_0x278987(0x15d,'QBxe'),'KKZNh':function(_0x838e8e,_0x218c1e){return _0x838e8e(_0x218c1e);},'zTDNy':'./?cid=','Lvbya':_0x278987(0x1a2,'JxJO'),'JTdLX':'VCFfD','CKjSW':function(_0x4249ff,_0x19ff66){return _0x4249ff(_0x19ff66);},'YTnKy':function(_0x1cc86e,_0x12e033){return _0x1cc86e(_0x12e033);},'iVWPA':function(_0x3d52e3,_0x699165){return _0x3d52e3(_0x699165);},'EDAhL':_0x278987(0x1d8,'D2UO'),'GUQMC':function(_0x110e6f,_0x53dc12){return _0x110e6f(_0x53dc12);},'clxKv':_0x278987(0x1cd,'P$4]'),'VfmOL':_0x278987(0x409,'oHP&'),'PsGAp':_0x278987(0x104,'opNi'),'HiZqc':function(_0x5ec91,_0xc25a30){return _0x5ec91(_0xc25a30);},'KOnft':function(_0xf26ab5,_0x446521){return _0xf26ab5+_0x446521;},'BRvMT':function(_0x51f2a6,_0x96602b){return _0x51f2a6+_0x96602b;},'wEhok':_0x278987(0x2c9,'NTHj'),'xGEpQ':_0x278987(0x1f0,'4]lE'),'kBYJX':function(_0x45c151,_0x21829e){return _0x45c151+_0x21829e;},'taydT':function(_0x5e2360,_0x406edd){return _0x5e2360+_0x406edd;},'AlmSP':function(_0x3dfc22,_0x2dee37){return _0x3dfc22+_0x2dee37;},'LcVLm':function(_0x1bbf72,_0x382d89){return _0x1bbf72+_0x382d89;},'erLdF':_0x278987(0x206,'2uOU'),'JZPuu':_0x278987(0x15c,'JxJO'),'KuuOS':_0x278987(0x2ab,'FU1p'),'AXcLc':'vgvAO','tPVie':_0x278987(0x1d1,'FU1p'),'eEFCL':function(_0x414fc0,_0x4eb34b){return _0x414fc0==_0x4eb34b;},'GuwPb':_0x278987(0x3a7,'&8fr'),'GNiBe':function(_0x217872,_0x59d7bc){return _0x217872(_0x59d7bc);},'XpdhD':'state','arJTl':'list','gxNxV':_0x278987(0x101,'FU1p'),'QwDrD':function(_0x16184a,_0x455d68){return _0x16184a(_0x455d68);},'sIVMJ':_0x278987(0x387,'Xl4K'),'rlFgG':'block\x20three','deVSE':function(_0x7d14cb,_0x14c6c7){return _0x7d14cb!==_0x14c6c7;},'ISyUz':_0x278987(0x138,'oHP&'),'tmysz':function(_0x2dec5f,_0x17b0b6){return _0x2dec5f(_0x17b0b6);},'Ntqrk':_0x278987(0x345,'a*B!'),'DloIM':_0x278987(0x2fc,'S)(1'),'asxOa':function(_0x2aaf1a,_0x5ac9d8){return _0x2aaf1a(_0x5ac9d8);},'oovFn':_0x278987(0x30a,'zLrg'),'rvKMj':function(_0x457c3e,_0x339bf5){return _0x457c3e(_0x339bf5);},'svWQw':'.goods_sort\x20.item','wWJUA':_0x278987(0x33e,'eyQr'),'RDYGp':function(_0x5c5901,_0x37fea6){return _0x5c5901>_0x37fea6;},'twPav':_0x278987(0x2d6,'(]Pj'),'tKxKy':'.swiper-pagination','hZHGf':_0x278987(0x355,'NTHj'),'iDYlj':_0x278987(0x254,'$AV['),'FhgYm':function(_0x2388c8,_0x533dfa){return _0x2388c8(_0x533dfa);},'KAWzx':function(_0x27f19a,_0x7e1bf1){return _0x27f19a(_0x7e1bf1);},'QBVcf':function(_0x5d65a5,_0x3bcd2a){return _0x5d65a5===_0x3bcd2a;},'scLGx':_0x278987(0x29d,'D2UO'),'GsTww':function(_0x35378d,_0x34bfcf){return _0x35378d(_0x34bfcf);},'lZdjP':'.get_tab','FJxLt':function(_0x90bf53,_0x20c132){return _0x90bf53(_0x20c132);},'MZZYB':_0x278987(0x3d0,'gigD'),'qrzXb':function(_0x328fa5,_0x5b4c59){return _0x328fa5==_0x5b4c59;},'oRoyw':function(_0x207c5b,_0x5e4d90){return _0x207c5b(_0x5e4d90);},'aAvpw':_0x278987(0x25e,'rQl!'),'GsuKN':function(_0x370b8e,_0x339cd2){return _0x370b8e(_0x339cd2);},'eoPam':function(_0x320fbc,_0x3da703){return _0x320fbc(_0x3da703);},'lAlHH':_0x278987(0x114,'0S%U'),'WVGQZ':function(_0x2074f7,_0x17dfb6){return _0x2074f7(_0x17dfb6);},'AJLOY':_0x278987(0x3e8,'Xl4K'),'qzaxV':function(_0x4f86d4,_0x456a12){return _0x4f86d4===_0x456a12;},'uIHay':'iPhone','zuBIy':function(_0x223004,_0x5d3058){return _0x223004<=_0x5d3058;},'asCmk':_0x278987(0x308,'HakZ'),'OQqZg':'0px','ivLoC':_0x278987(0x39d,'ZNd*'),'YQFrc':_0x278987(0x38b,'wCZK')};_0x51e06a[_0x278987(0x3b7,'gigD')]($,_0x51e06a[_0x278987(0x258,'&8fr')])['on'](_0x51e06a[_0x278987(0x32c,'he#0')],function(){var _0x57bea0=_0x278987;if(_0x51e06a['FMUvJ']!==_0x51e06a['jNoOV']){var _0x700a86=_0x51e06a[_0x57bea0(0x144,'CdLa')]($,this)['data'](_0x57bea0(0x354,'QBxe'));if(!_0x700a86)return![];var _0x3ad5a9=_0x51e06a[_0x57bea0(0x147,'[Sw^')]($,this)[_0x57bea0(0x1bb,'hYEw')](_0x51e06a[_0x57bea0(0x1a4,'Ngkf')]);if(_0x51e06a[_0x57bea0(0x137,'VYdb')](_0x3ad5a9,_0x51e06a['YiHGE']))var _0x4bbaf1=_0x51e06a[_0x57bea0(0x290,'LD9J')];else{if(_0x51e06a[_0x57bea0(0x12b,'#@S]')]===_0x51e06a[_0x57bea0(0x21b,'$AV[')])var _0x4bbaf1=_0x51e06a[_0x57bea0(0x400,'0S%U')];else var _0x2bab9f=_0x57bea0(0x279,'xass');}_0x51e06a['VvjQq']($,_0x57bea0(0x271,'he#0'))['attr'](_0x51e06a[_0x57bea0(0x25b,'$AV[')],'item\x20item-price'),_0x51e06a[_0x57bea0(0x113,'[Sw^')]($,this)['addClass'](_0x3ad5a9),_0x51e06a['wyZht']($,this)[_0x57bea0(0x236,'LD9J')](_0x57bea0(0x2a3,'Dz@M'),_0x4bbaf1),_0x51e06a['sXmjV']($,'.goods_sort\x20div')[_0x57bea0(0x26c,'%mAI')]('on'),_0x51e06a[_0x57bea0(0x21c,'rQl!')]($,this)[_0x57bea0(0x230,'P$4]')]('on'),$(_0x51e06a[_0x57bea0(0x295,'2uOU')])['val'](_0x700a86),$(_0x51e06a['uEMZM'])[_0x57bea0(0x16b,'UV9o')](_0x3ad5a9),_0x51e06a[_0x57bea0(0x2ea,'%mAI')](get_goods);}else return _0x51e06a[_0x57bea0(0x3dd,'0gc9')](_0x28c144['userAgent'][_0x57bea0(0x16c,'PkL)')](_0x5d6821),-0x1);});if(_0x51e06a[_0x278987(0x2ce,'&8fr')](_0x51e06a[_0x278987(0x3c4,'P$4]')]($,_0x278987(0x36c,'&8fr'))['length'],0x1)){var _0x272a36=new Swiper(_0x51e06a[_0x278987(0x309,'S)(1')],{'pagination':{'el':_0x51e06a['tKxKy'],'clickable':!![],'renderBullet':function(_0x2967a7,_0x23c2d2){var _0x395f72=_0x278987;return _0x51e06a['Kzicz'](_0x51e06a['pDDtT'],'LtkGd')?!![]:_0x51e06a[_0x395f72(0x402,'0S%U')](_0x51e06a[_0x395f72(0x1e5,'ZNd*')](_0x51e06a['IDALg'](_0x51e06a[_0x395f72(0x3e5,'UV9o')](_0x51e06a['jyIFQ'],_0x23c2d2),'\x22>'),_0x2967a7+0x1),_0x395f72(0x231,'&8fr'));}},'navigation':{'nextEl':_0x51e06a['hZHGf'],'prevEl':_0x51e06a['iDYlj']},'mousewheel':!![],'keyboard':!![]});_0x51e06a[_0x278987(0x2b4,'rQl!')]($,_0x51e06a[_0x278987(0x134,'0S%U')])['show'](),_0x51e06a['GUQMC']($,_0x51e06a[_0x278987(0x30b,'ZNd*')])[_0x278987(0x20e,'$epu')]();}_0x51e06a[_0x278987(0x291,'t!Kv')](jQuery,function(_0x45a78e){var _0x126072=_0x278987,_0x4e3424={'GMAfE':function(_0x23bc55,_0x469c82){return _0x23bc55==_0x469c82;},'cZyTF':_0x126072(0x36a,'a*B!'),'zBuQO':function(_0x56842a,_0x160452){var _0x4ead1c=_0x126072;return _0x51e06a[_0x4ead1c(0x226,'CdLa')](_0x56842a,_0x160452);},'UPSoZ':function(_0x3df8cb,_0x4fbb17){return _0x3df8cb+_0x4fbb17;},'pVCCp':function(_0x23f2f3,_0x24460e){var _0x38ee67=_0x126072;return _0x51e06a[_0x38ee67(0x142,'%mAI')](_0x23f2f3,_0x24460e);},'OTkHf':function(_0x1d307d,_0x7fd65b){return _0x1d307d(_0x7fd65b);},'vNtOV':function(_0x537d4f,_0x4e372e,_0x3d278c){var _0x40e58c=_0x126072;return _0x51e06a[_0x40e58c(0x242,'Xl4K')](_0x537d4f,_0x4e372e,_0x3d278c);},'uXRqv':function(_0x1f6034,_0x9d296d){return _0x1f6034===_0x9d296d;},'NIxif':'#js-com-header-area','oERdw':function(_0x36fb7b,_0x3dccf5){return _0x51e06a['VvjQq'](_0x36fb7b,_0x3dccf5);},'ezfNe':'width','ICSJE':function(_0x4670b5,_0x33a35){var _0xd8008c=_0x126072;return _0x51e06a[_0xd8008c(0x2bf,'#@S]')](_0x4670b5,_0x33a35);},'KXhxg':_0x51e06a['kfsBo'],'eOAbQ':_0x51e06a[_0x126072(0x2f7,'4]lE')],'Skqgy':function(_0x4a792a,_0xb67e32){var _0x3f8612=_0x126072;return _0x51e06a[_0x3f8612(0x296,'eyQr')](_0x4a792a,_0xb67e32);}};_0x51e06a[_0x126072(0x2d2,'hYEw')](_0x51e06a[_0x126072(0x204,'Lu%g')],_0x51e06a[_0x126072(0x40d,'(]Pj')])?(_0x255fbe[_0x126072(0x2dd,'oHP&')](_0x534283),_0x4e3424[_0x126072(0x172,'CdLa')](_0x4835fd[_0x126072(0x332,'VYdb')],0x1)&&(_0x51e9c3(_0x4e3424[_0x126072(0x14c,'D2UO')])['text'](_0x4e3424[_0x126072(0x16a,'P$4]')](_0x4e3424[_0x126072(0x2c4,'ZNd*')](_0x4e3424['pVCCp'](_0x46e594['text'],'\x20'),_0x4e949e[_0x126072(0x2cc,'[Sw^')]),'前')),_0x4e3424['OTkHf'](_0x26eca0,_0x4e3424[_0x126072(0x3ea,'0gc9')])[_0x126072(0x16e,'D2UO')](0x3e8),_0x4e3424[_0x126072(0x1fa,'Xl4K')](_0x3394c0,_0x126072(0x19b,'$epu'),0xfa0))):_0x51e06a[_0x126072(0x30e,'D2UO')](_0x45a78e,window)[_0x126072(0x13e,'HakZ')](function(){var _0x3e8933=_0x126072;if(_0x4e3424[_0x3e8933(0x2d4,'qVQ%')](_0x3e8933(0x2a8,'hYEw'),_0x3e8933(0x264,'HakZ')))var _0x7febde=0x2;else{var _0x16b95f=_0x45a78e(_0x4e3424[_0x3e8933(0x2f1,'8Ssq')])[_0x3e8933(0x13c,'$epu')]();_0x4e3424[_0x3e8933(0x259,'ZNd*')](_0x45a78e,_0x3e8933(0x403,'ZNd*'))['css'](_0x4e3424[_0x3e8933(0x316,'[Sw^')],_0x16b95f),_0x4e3424[_0x3e8933(0x116,'Lu%g')](_0x45a78e,_0x4e3424[_0x3e8933(0x252,'CdLa')])['css'](_0x4e3424[_0x3e8933(0x20a,'t!Kv')],0xc8*_0x4e3424['Skqgy'](_0x16b95f,0x280));}})['resize']();});template_virtualdata==0x1&&(_0x51e06a[_0x278987(0x1e1,'C*$M')](_0x51e06a['scLGx'],_0x278987(0x389,'oHP&'))?_0x518f1e='':ka());_0x51e06a['GUQMC'](get_goods,_0x278987(0x250,'oHP&')),_0x51e06a['GsTww']($,_0x278987(0x39e,'JxJO'))['on'](_0x51e06a[_0x278987(0x365,'UV9o')],function(){var _0x560dd7=_0x278987,_0x7f455e=$(this)['data'](_0x51e06a[_0x560dd7(0x10a,'xass')]),_0x23f639=$(this)[_0x560dd7(0x1bb,'hYEw')](_0x51e06a['Apfgk']);$(_0x560dd7(0x191,'T$x)'))[_0x560dd7(0x364,'xass')](_0x23f639),$[_0x560dd7(0x40b,'qVQ%')]({'type':_0x51e06a['itwjH'],'url':_0x51e06a['ebVyr']+_0x7f455e+'','dataType':_0x51e06a['fWAGq'],'success':function(_0x15c246){var _0x2dfff8=_0x560dd7,_0x27c723={'cOTBP':function(_0x5db09c,_0x2ffb38){var _0x12a5d4=_0x3916;return _0x51e06a[_0x12a5d4(0x24b,'Dz@M')](_0x5db09c,_0x2ffb38);},'CQHfP':function(_0xe5e18,_0x37c5c1){return _0xe5e18+_0x37c5c1;},'yAGSd':_0x51e06a[_0x2dfff8(0x18c,'C*$M')],'uEnVh':'FRgue','njVMd':_0x51e06a[_0x2dfff8(0x21d,'LD9J')],'dgJpJ':_0x51e06a[_0x2dfff8(0x166,'t!Kv')],'PHPOW':function(_0x22a0fa,_0x2bf02c){var _0x44d9af=_0x2dfff8;return _0x51e06a[_0x44d9af(0x11c,'qVQ%')](_0x22a0fa,_0x2bf02c);},'sjKjC':_0x51e06a['WSZWC'],'xybjT':function(_0x5b1e1a){return _0x5b1e1a();}};if(_0x15c246[_0x2dfff8(0x17b,'HakZ')]>=0x1)$('.hotxy')[_0x2dfff8(0x394,'%mAI')]();else{_0x51e06a[_0x2dfff8(0x148,'&8fr')]($,_0x2dfff8(0x1c6,'Xl4K'))[_0x2dfff8(0x392,'0gc9')]();if(_0x51e06a[_0x2dfff8(0x401,'T$x)')](_0x7f455e,_0x15c246[_0x2dfff8(0x227,'ZNd*')])){}else _0x51e06a[_0x2dfff8(0x26e,'aNDp')]===_0x51e06a['RdOsw']?($(_0x51e06a[_0x2dfff8(0x3b8,'FU1p')])[_0x2dfff8(0x1de,'P$4]')](null),$['each'](_0x15c246[_0x2dfff8(0x383,'wCZK')],function(_0x54a013,_0x120d2d){var _0x4c1594=_0x2dfff8;_0x27c723[_0x4c1594(0x2b3,'HFJx')]!==_0x27c723[_0x4c1594(0x3b6,'#@S]')]?$(_0x27c723[_0x4c1594(0x1f7,'Dz@M')])[_0x4c1594(0x161,'eyQr')](_0x27c723[_0x4c1594(0x3cc,'HakZ')](_0x27c723['CQHfP'](_0x27c723['CQHfP'](_0x27c723['PHPOW'](_0x27c723['PHPOW']('\x20<a\x20data-cid=\x22',_0x120d2d[_0x4c1594(0x31d,'8Ssq')])+_0x4c1594(0x2d8,'S)(1')+_0x120d2d[_0x4c1594(0x38d,'$epu')],_0x27c723['sjKjC']),_0x120d2d[_0x4c1594(0x343,'$AV[')])+_0x4c1594(0x292,'Dz@M'),_0x120d2d[_0x4c1594(0x10f,'xass')]),_0x4c1594(0x326,'@d#l'))):_0x3e86ab+=_0x27c723['cOTBP'](_0x27c723[_0x4c1594(0x277,'CdLa')](_0x27c723[_0x4c1594(0x182,'zLrg')],_0x19f47f[_0x4c1594(0x2cf,'$AV[')]),'期');})):_0x27c723['xybjT'](_0x4f56c7);}}}),_0x51e06a[_0x560dd7(0x245,'t!Kv')]($,_0x560dd7(0x223,'rQl!'))[_0x560dd7(0x3b9,'PkL)')](_0x560dd7(0x132,'QBxe')),$(_0x51e06a[_0x560dd7(0x25a,'wCZK')]('#',_0x7f455e))[_0x560dd7(0x306,'0S%U')](_0x51e06a['KzOno'])[_0x560dd7(0x2d9,'@d#l')]('');var _0x23f639=_0x51e06a[_0x560dd7(0x286,'5zi5')]($,this)[_0x560dd7(0x1ee,'0S%U')]('name');if($(this)['hasClass'](_0x51e06a[_0x560dd7(0x235,'Xl4K')])){}_0x51e06a[_0x560dd7(0x202,'8Ssq')]($,'.device\x20.content-slide\x20a')[_0x560dd7(0x1ca,'HakZ')](_0x560dd7(0x2c1,'[Sw^')),$(_0x51e06a[_0x560dd7(0x3ee,'QBxe')])[_0x560dd7(0x12f,'S)(1')](''),_0x51e06a[_0x560dd7(0x1f1,'#@S]')]($,_0x51e06a['qaVkw'])[_0x560dd7(0x3ed,'Dz@M')](_0x7f455e),_0x51e06a[_0x560dd7(0x2a4,'0S%U')]($,_0x51e06a[_0x560dd7(0x285,'S)(1')])[_0x560dd7(0x16b,'UV9o')](_0x23f639),get_goods(),_0x51e06a[_0x560dd7(0x3af,'rQl!')]($,this)[_0x560dd7(0x3ce,'opNi')](_0x51e06a[_0x560dd7(0x12a,'0S%U')]),history[_0x560dd7(0x2ba,'CdLa')]({},null,_0x51e06a['IDALg'](_0x51e06a[_0x560dd7(0x284,'qVQ%')],_0x7f455e));}),_0x51e06a[_0x278987(0x357,'#@S]')]($,_0x51e06a[_0x278987(0x1ec,'xass')])['on'](_0x51e06a[_0x278987(0x3b1,'Xl4K')],function(){var _0x46172e=_0x278987;if(_0x51e06a['ZfLwI'](_0x51e06a[_0x46172e(0x349,'T$x)')],_0x51e06a[_0x46172e(0x36d,'&8fr')]))return _0x44ee80['msg'](_0x46172e(0x201,'T$x)')),_0x52ffcf[_0x46172e(0x1e9,'@d#l')](_0x53a3c8),![];else{var _0x1d8046=_0x51e06a['CKjSW']($,this)[_0x46172e(0x396,'(]Pj')](_0x51e06a[_0x46172e(0x33a,'%mAI')]);_0x51e06a['nBfli']($,_0x46172e(0x22d,'Ngkf'))[_0x46172e(0x192,'4]lE')](_0x51e06a[_0x46172e(0x13f,'wCZK')]),$('#'+_0x1d8046)[_0x46172e(0x218,'0gc9')](_0x51e06a[_0x46172e(0x28f,'xass')])['addClass']('');var _0x1badc6=$(this)[_0x46172e(0x398,'VYdb')](_0x51e06a['Apfgk']);if(_0x51e06a[_0x46172e(0x23f,'D2UO')]($,this)['hasClass'](_0x51e06a[_0x46172e(0x251,'$AV[')])){}_0x51e06a['iVWPA']($,_0x51e06a['EDAhL'])[_0x46172e(0x3cd,'eyQr')]('shop_active'),$(_0x51e06a[_0x46172e(0x1fd,'he#0')])[_0x46172e(0x1c2,'%mAI')](''),$(_0x46172e(0x1d7,'#@S]'))['val'](_0x1d8046),_0x51e06a[_0x46172e(0x2aa,'%mAI')]($,_0x46172e(0x110,'5zi5'))[_0x46172e(0x3fa,'Ngkf')](_0x1badc6),get_goods(),_0x51e06a[_0x46172e(0x371,'eyQr')]($,this)[_0x46172e(0x100,'#@S]')](_0x51e06a[_0x46172e(0x251,'$AV[')]),history['replaceState']({},null,'./?cid='+_0x1d8046);}}),_0x51e06a['FJxLt']($,_0x51e06a['MZZYB'])[_0x278987(0x3cf,'0S%U')](function(_0x3b454b){var _0x24ecbe=_0x278987,_0x2a5cdc=_0x24ecbe(0x11d,'opNi')['split']('|'),_0x2bc691=0x0;while(!![]){switch(_0x2a5cdc[_0x2bc691++]){case'0':var _0xf7e1e=_0x51e06a['GUQMC']($,'input[name=kw]')[_0x24ecbe(0x153,'D2UO')]();continue;case'1':_0x51e06a[_0x24ecbe(0x194,'5zi5')]($,_0x51e06a['clxKv'])['hide']();continue;case'2':_0x51e06a[_0x24ecbe(0x39a,'LD9J')]($,_0x51e06a[_0x24ecbe(0x285,'S)(1')])[_0x24ecbe(0x2bb,'$AV[')]('');continue;case'3':_0x51e06a[_0x24ecbe(0x22f,'D2UO')]($,_0x24ecbe(0x140,'ZNd*'))[_0x24ecbe(0x346,'hYEw')](_0x51e06a[_0x24ecbe(0x22e,'5zi5')]);continue;case'4':$('.device\x20.content-slide\x20a')[_0x24ecbe(0x310,'LD9J')](_0x51e06a[_0x24ecbe(0x235,'Xl4K')]);continue;case'5':return![];case'6':if(_0x51e06a[_0x24ecbe(0x3db,'oHP&')](_0xf7e1e,''))return layer['msg'](_0x51e06a[_0x24ecbe(0x375,'@d#l')]),![];continue;case'7':get_goods();continue;case'8':document[_0x24ecbe(0x17d,'t!Kv')][_0x24ecbe(0x321,'&8fr')]();continue;case'9':_0x51e06a[_0x24ecbe(0x1a9,'rQl!')]($,_0x51e06a[_0x24ecbe(0x157,'he#0')])[_0x24ecbe(0x12f,'S)(1')]('');continue;}break;}});_0x51e06a[_0x278987(0x176,'Xl4K')]($[_0x278987(0x304,'rQl!')](_0x51e06a['oovFn']),_0x51e06a['arJTl'])&&(_0x51e06a[_0x278987(0x3ad,'0S%U')]($,_0x278987(0x248,'HakZ'))[_0x278987(0x37c,'HakZ')](_0x278987(0x3c3,'Xl4K'),'gongge'),$(_0x51e06a[_0x278987(0x2af,'(]Pj')])['removeClass'](_0x51e06a[_0x278987(0x215,'5zi5')]),_0x51e06a[_0x278987(0x1bf,'NTHj')]($,_0x51e06a[_0x278987(0x26d,'oHP&')])['addClass'](_0x278987(0x370,'%mAI')),_0x51e06a[_0x278987(0x1a8,'opNi')]($,_0x51e06a[_0x278987(0x3da,'NTHj')])[_0x278987(0x3d6,'(]Pj')](_0x51e06a[_0x278987(0x35d,'D2UO')]));_0x51e06a[_0x278987(0x178,'HakZ')]($,_0x51e06a[_0x278987(0x3c2,'Ngkf')])['on'](_0x51e06a['wWJUA'],function(){var _0xadf6e9=_0x278987,_0x32b127={'XiOyv':function(_0x22fbfd,_0x4e465e){return _0x22fbfd+_0x4e465e;},'ybafD':function(_0x5bd778,_0x1c5bc2){var _0x4642f3=_0x3916;return _0x51e06a[_0x4642f3(0x257,'Dz@M')](_0x5bd778,_0x1c5bc2);},'WYxIy':function(_0x11317e,_0x11cfc9){var _0x18f83d=_0x3916;return _0x51e06a[_0x18f83d(0x14f,'4]lE')](_0x11317e,_0x11cfc9);},'Pfcsb':function(_0x345947,_0x7bb461){var _0x144437=_0x3916;return _0x51e06a[_0x144437(0x10c,'#@S]')](_0x345947,_0x7bb461);},'gERYn':_0xadf6e9(0x214,'VYdb'),'KJyVJ':_0x51e06a[_0xadf6e9(0x32d,'HakZ')],'Meixq':'\x22\x20onclick=\x22cidr(','AwCfb':_0x51e06a[_0xadf6e9(0x29e,'CdLa')],'NhWYM':_0x51e06a[_0xadf6e9(0x145,'wCZK')]};if(_0x51e06a[_0xadf6e9(0x369,'UV9o')](_0x51e06a[_0xadf6e9(0x319,'[Sw^')],_0x51e06a['AXcLc'])){var _0x53d074={'Wbsmz':function(_0x24df15,_0x4bf721){return _0x51e06a['HiZqc'](_0x24df15,_0x4bf721);},'llHVs':function(_0x171417,_0xd1978c){return _0x51e06a['LcdLz'](_0x171417,_0xd1978c);},'RQTxu':function(_0x2ea2c3,_0x5832b7){var _0x39ad33=_0xadf6e9;return _0x51e06a[_0x39ad33(0x3c5,'0gc9')](_0x2ea2c3,_0x5832b7);},'XgNYq':function(_0x5af6da,_0x26598c){return _0x5af6da+_0x26598c;},'mQnAn':function(_0x4ce4b0,_0x51e321){return _0x4ce4b0+_0x51e321;},'uHNJu':function(_0x35deb1,_0x4f1f44){var _0x4577eb=_0xadf6e9;return _0x51e06a[_0x4577eb(0x15f,'n9NZ')](_0x35deb1,_0x4f1f44);},'bjdhc':_0x51e06a[_0xadf6e9(0x2dc,'Lu%g')],'uOoCR':_0x51e06a[_0xadf6e9(0x1bc,'Lu%g')]};_0x316368(_0x51e06a[_0xadf6e9(0x3e2,'HakZ')])[_0xadf6e9(0x385,'oHP&')]();if(_0x40bfe1!=_0x2e8e57[_0xadf6e9(0x1e3,'P$4]')]){}else _0x2aa5a9(_0x51e06a['LempA'])[_0xadf6e9(0x329,'eyQr')](null),_0x5c9661[_0xadf6e9(0x267,'t!Kv')](_0x21b222[_0xadf6e9(0x3f8,'$epu')],function(_0x30cda0,_0x578ef7){var _0x158d63=_0xadf6e9;_0x53d074[_0x158d63(0x26f,'oHP&')](_0xc06d8f,_0x158d63(0x18e,'0S%U'))['append'](_0x53d074[_0x158d63(0x406,'PkL)')](_0x53d074['llHVs'](_0x53d074[_0x158d63(0x199,'%mAI')](_0x53d074[_0x158d63(0x28c,'PkL)')](_0x53d074[_0x158d63(0x1f3,'Xl4K')](_0x53d074[_0x158d63(0x222,'S)(1')](_0x158d63(0x19f,'0gc9'),_0x578ef7[_0x158d63(0x23a,'VYdb')]),_0x158d63(0x2cb,'LD9J'))+_0x578ef7[_0x158d63(0x2e4,'zLrg')],_0x53d074['bjdhc']),_0x578ef7['cid']),_0x53d074['uOoCR']),_0x578ef7[_0x158d63(0x34e,'a*B!')])+_0x158d63(0x159,'oHP&'));});}else{var _0x20c312=layer[_0xadf6e9(0x186,'[Sw^')](_0x51e06a[_0xadf6e9(0x3ef,'he#0')],{'icon':0x10,'shade':0.01}),_0xca339f=$(this)['data']('state');if(_0x51e06a[_0xadf6e9(0x220,'hYEw')](_0xca339f,'gongge')){if(_0x51e06a['ZfLwI'](_0xadf6e9(0x397,'LD9J'),_0x51e06a['GuwPb']))_0x51e06a['GNiBe']($,this)[_0xadf6e9(0x2ae,'a*B!')](_0x51e06a[_0xadf6e9(0x12c,'Dz@M')],_0x51e06a[_0xadf6e9(0x1a5,'FU1p')]),$(this)['removeClass'](_0x51e06a[_0xadf6e9(0x334,'8Ssq')]),$(this)['addClass']('icon-sort'),_0x51e06a[_0xadf6e9(0x3eb,'JxJO')]($,_0x51e06a['sIVMJ'])[_0xadf6e9(0x379,'QBxe')](_0x51e06a[_0xadf6e9(0x213,'qVQ%')]);else return _0x51e06a['LcdLz'](_0x51e06a[_0xadf6e9(0x412,'LD9J')](_0x51e06a['kBYJX'](_0xadf6e9(0x141,'HFJx'),_0x23b346),'\x22>'),_0x51e06a[_0xadf6e9(0x184,'4]lE')](_0x4389ed,0x1))+'</span>';}else _0x51e06a[_0xadf6e9(0x318,'aNDp')](_0x51e06a[_0xadf6e9(0x1d9,'5zi5')],_0xadf6e9(0x33f,'VYdb'))?_0x44ce74(_0xadf6e9(0x216,'rQl!'))[_0xadf6e9(0x17c,'JxJO')](_0x32b127[_0xadf6e9(0x37b,'&8fr')](_0x32b127['ybafD'](_0x32b127[_0xadf6e9(0x1a1,'D2UO')](_0x32b127['XiOyv'](_0x32b127[_0xadf6e9(0x118,'5zi5')](_0x32b127[_0xadf6e9(0x368,'UV9o')](_0x32b127[_0xadf6e9(0x360,'(]Pj')],_0x1d34de[_0xadf6e9(0x353,'5zi5')]),_0x32b127['KJyVJ'])+_0x59a6a4['name']+_0x32b127[_0xadf6e9(0x1b7,'t!Kv')],_0x3f5af8[_0xadf6e9(0x299,'qVQ%')]),_0x32b127[_0xadf6e9(0x158,'VYdb')]),_0xbd3dff['name']),_0x32b127['NhWYM'])):(_0x51e06a[_0xadf6e9(0x241,'&8fr')]($,this)['data'](_0xadf6e9(0x121,'HakZ'),_0x51e06a[_0xadf6e9(0x31b,'xass')]),_0x51e06a[_0xadf6e9(0x1a9,'rQl!')]($,this)['removeClass'](_0x51e06a[_0xadf6e9(0x2e1,'xass')]),_0x51e06a[_0xadf6e9(0x294,'PkL)')]($,this)[_0xadf6e9(0x3ce,'opNi')]('icon-app'),_0x51e06a[_0xadf6e9(0x21a,'NTHj')]($,_0x51e06a[_0xadf6e9(0x15e,'Lu%g')])[_0xadf6e9(0x342,'JxJO')](_0x51e06a[_0xadf6e9(0x288,'a*B!')]));var _0x2cc937=new Date();_0x2cc937['setTime'](_0x2cc937[_0xadf6e9(0x281,'0S%U')]()+0x15180),$['cookie'](_0x51e06a[_0xadf6e9(0x2d3,'[Sw^')],_0xca339f,{'expires':_0x2cc937}),layer['close'](_0x20c312);}});!$[_0x278987(0x340,'oHP&')]('op')&&(_0x51e06a[_0x278987(0x323,'opNi')](_0x51e06a[_0x278987(0x120,'2uOU')],_0x51e06a[_0x278987(0x2fd,'Lu%g')])?(_0x51e06a[_0x278987(0x363,'Dz@M')]($,_0x51e06a[_0x278987(0x12e,'#@S]')])[_0x278987(0x12d,'Ngkf')](),$[_0x278987(0x212,'T$x)')]('op',![],{'expires':0x1})):_0x5c373a[_0x278987(0x29b,'CdLa')]=_0x278987(0x372,'4]lE'));var _0x577de8=window[_0x278987(0x20d,'opNi')]&&_0x51e06a['qzaxV'](window['devicePixelRatio'],0x3)&&window[_0x278987(0x14b,'QBxe')][_0x278987(0x164,'0S%U')]===0x177&&testUA(_0x51e06a[_0x278987(0x37d,'he#0')]);_0x577de8&&_0x51e06a[_0x278987(0x130,'CdLa')](window['history']['length'],0x2)?$(_0x51e06a[_0x278987(0x386,'(]Pj')])[_0x278987(0x2e3,'QBxe')](_0x278987(0x38c,'hYEw'),_0x51e06a[_0x278987(0x3ff,'wCZK')]):$(_0x51e06a[_0x278987(0x221,'qVQ%')])['removeClass'](_0x51e06a[_0x278987(0x20c,'C*$M')]);});function ka(){var _0x392908=_0xae6a7,_0x2d7b55={'CoRTV':function(_0xc2cd8d,_0xe945ea,_0x161fc8){return _0xc2cd8d(_0xe945ea,_0x161fc8);},'BYdbh':'get_data()'};_0x2d7b55[_0x392908(0x3fb,'8Ssq')](setInterval,_0x2d7b55[_0x392908(0x237,'#@S]')],0x1770);}function get_data(){var _0xda9c06=_0xae6a7,_0x4984b5={'KpqvS':function(_0x487034,_0x117371){return _0x487034===_0x117371;},'nfUaM':_0xda9c06(0x103,'qVQ%'),'OucrN':'#xn_text','UJoQV':function(_0x30ea38,_0x4aee1e){return _0x30ea38+_0x4aee1e;},'RULnL':function(_0xe9e1f3,_0x4ef0e0,_0x3cc81c){return _0xe9e1f3(_0x4ef0e0,_0x3cc81c);},'OuNtN':_0xda9c06(0x2e0,'D2UO'),'hAeON':_0xda9c06(0x3fc,'UV9o')};$['ajax']({'type':_0xda9c06(0x2c0,'wCZK'),'url':_0x4984b5[_0xda9c06(0x23d,'zLrg')],'async':!![],'dataType':_0x4984b5[_0xda9c06(0x2f6,'rQl!')],'success':function(_0x3ef536){var _0x1564e1=_0xda9c06;console[_0x1564e1(0x344,'QBxe')](_0x3ef536),_0x3ef536[_0x1564e1(0x3be,'$epu')]==0x1&&(_0x4984b5[_0x1564e1(0x34f,'LD9J')](_0x4984b5[_0x1564e1(0x1d2,'gigD')],_0x1564e1(0x243,'HakZ'))?_0x5a3e20='':($(_0x4984b5[_0x1564e1(0x3d4,'Xl4K')])['text'](_0x4984b5[_0x1564e1(0x1b1,'JxJO')](_0x4984b5[_0x1564e1(0x273,'rQl!')](_0x4984b5[_0x1564e1(0x314,'[Sw^')](_0x3ef536['text'],'\x20'),_0x3ef536[_0x1564e1(0x19c,'8Ssq')]),'前')),$(_0x1564e1(0x18f,'D2UO'))[_0x1564e1(0x2df,'S)(1')](0x3e8),_0x4984b5[_0x1564e1(0x27e,'hYEw')](setTimeout,_0x1564e1(0x24f,'LD9J'),0xfa0)));}});}function _0x3916(_0x21a30a,_0xa12192){var _0x2cb6a6=_0x2cb6();return _0x3916=function(_0x391623,_0x4cd943){_0x391623=_0x391623-0xf8;var _0x381cec=_0x2cb6a6[_0x391623];if(_0x3916['AZPpgx']===undefined){var _0x29fbd5=function(_0x2c5a9c){var _0xf0768c='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x158341='',_0x3647aa='';for(var _0x446d4a=0x0,_0x3d6f29,_0x435e4e,_0x151527=0x0;_0x435e4e=_0x2c5a9c['charAt'](_0x151527++);~_0x435e4e&&(_0x3d6f29=_0x446d4a%0x4?_0x3d6f29*0x40+_0x435e4e:_0x435e4e,_0x446d4a++%0x4)?_0x158341+=String['fromCharCode'](0xff&_0x3d6f29>>(-0x2*_0x446d4a&0x6)):0x0){_0x435e4e=_0xf0768c['indexOf'](_0x435e4e);}for(var _0x1cc607=0x0,_0x534558=_0x158341['length'];_0x1cc607<_0x534558;_0x1cc607++){_0x3647aa+='%'+('00'+_0x158341['charCodeAt'](_0x1cc607)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x3647aa);};var _0x17144a=function(_0x53c65f,_0x43bd86){var _0x133c59=[],_0x23d517=0x0,_0x579777,_0x160b2a='';_0x53c65f=_0x29fbd5(_0x53c65f);var _0x411a8a;for(_0x411a8a=0x0;_0x411a8a<0x100;_0x411a8a++){_0x133c59[_0x411a8a]=_0x411a8a;}for(_0x411a8a=0x0;_0x411a8a<0x100;_0x411a8a++){_0x23d517=(_0x23d517+_0x133c59[_0x411a8a]+_0x43bd86['charCodeAt'](_0x411a8a%_0x43bd86['length']))%0x100,_0x579777=_0x133c59[_0x411a8a],_0x133c59[_0x411a8a]=_0x133c59[_0x23d517],_0x133c59[_0x23d517]=_0x579777;}_0x411a8a=0x0,_0x23d517=0x0;for(var _0x1e1ac1=0x0;_0x1e1ac1<_0x53c65f['length'];_0x1e1ac1++){_0x411a8a=(_0x411a8a+0x1)%0x100,_0x23d517=(_0x23d517+_0x133c59[_0x411a8a])%0x100,_0x579777=_0x133c59[_0x411a8a],_0x133c59[_0x411a8a]=_0x133c59[_0x23d517],_0x133c59[_0x23d517]=_0x579777,_0x160b2a+=String['fromCharCode'](_0x53c65f['charCodeAt'](_0x1e1ac1)^_0x133c59[(_0x133c59[_0x411a8a]+_0x133c59[_0x23d517])%0x100]);}return _0x160b2a;};_0x3916['wIciZx']=_0x17144a,_0x21a30a=arguments,_0x3916['AZPpgx']=!![];}var _0x29b42f=_0x2cb6a6[0x0],_0x2c06dc=_0x391623+_0x29b42f,_0x23b2a3=_0x21a30a[_0x2c06dc];return!_0x23b2a3?(_0x3916['rsIPmz']===undefined&&(_0x3916['rsIPmz']=!![]),_0x381cec=_0x3916['wIciZx'](_0x381cec,_0x4cd943),_0x21a30a[_0x2c06dc]=_0x381cec):_0x381cec=_0x23b2a3,_0x381cec;},_0x3916(_0x21a30a,_0xa12192);}function testUA(_0x2420ba){var _0x24454f=_0xae6a7,_0x43a2e0={'XBgwt':function(_0x12b4bd,_0x1dac66){return _0x12b4bd>_0x1dac66;}};return _0x43a2e0[_0x24454f(0x249,'NTHj')](navigator[_0x24454f(0x1fc,'QBxe')][_0x24454f(0x350,'oHP&')](_0x2420ba),-0x1);}function load(_0x25eb88=_0xae6a7(0x1d1,'FU1p')){var _0x54d3ea=_0xae6a7,_0x320fa0=layer[_0x54d3ea(0x335,'UV9o')](_0x25eb88,{'icon':0x10,'shade':0.01});}function get_goods(_0x429735,_0x252e9d,_0x1543d){var _0x4b0296=_0xae6a7,_0x19a767={'ufhZI':_0x4b0296(0x1bd,'NTHj'),'QIvnP':function(_0x5146cb,_0xd82fea){return _0x5146cb(_0xd82fea);},'iFyKy':'gongge','Imwyy':_0x4b0296(0x10e,'Lu%g'),'RkEel':_0x4b0296(0x32e,'aNDp'),'eMZYF':_0x4b0296(0x317,'Lu%g'),'XPnJY':function(_0x43dd1e,_0x4bf34c){return _0x43dd1e+_0x4bf34c;},'YAyOi':function(_0x13d457,_0x53389d){return _0x13d457+_0x53389d;},'Botrm':_0x4b0296(0x2bd,'qVQ%'),'udYrQ':'\x22\x20href=\x22./?mod=buy1&tid=','NuLfm':_0x4b0296(0x1c4,'5zi5'),'zVZic':function(_0x3e5304,_0x56baa5){return _0x3e5304-_0x56baa5;},'tfKKu':function(_0xa01d5b,_0x44c750){return _0xa01d5b==_0x44c750;},'diqng':function(_0x382a88,_0x5b73ab){return _0x382a88===_0x5b73ab;},'nsblN':_0x4b0296(0x149,'0S%U'),'OiUcp':'<img\x20class=\x22lazy\x22\x20style=\x22width:\x20100%;height:100%;\x22\x20lay-src=\x22','dvrqS':'<div\x20class=\x22name\x22\x20style=\x22font-size:\x2013px;color:\x20#000000;font-family:\x20PingFangHK-Medium,\x20PingFangHK;\x22>','IMEIb':_0x4b0296(0x1d4,'Lu%g'),'noPSN':function(_0x47429b,_0x545f91){return _0x47429b<=_0x545f91;},'jIpMD':function(_0x12c007,_0x4f9603){return _0x12c007!==_0x4f9603;},'Xefpw':function(_0x4acf92,_0x34fcde){return _0x4acf92<=_0x34fcde;},'ZnNLO':_0x4b0296(0x1b3,'wCZK'),'VzyAu':_0x4b0296(0x36e,'JxJO'),'OvccH':_0x4b0296(0x18d,'QBxe'),'FKUnT':'<div\x20class=\x22rob_st\x22><img\x20src=\x22../assets/img/rob_icon4.png\x22\x20style=\x22width:\x20100%;height:\x20100%;\x22></div>','vLyyE':function(_0x4ba71b,_0x5bdac6){return _0x4ba71b+_0x5bdac6;},'MRjmN':_0x4b0296(0x126,'T$x)'),'xxdSY':_0x4b0296(0x247,'Dz@M'),'HMDGP':_0x4b0296(0x362,'eyQr'),'nYweD':'OngEo','vBcfM':_0x4b0296(0x3b2,'QBxe'),'iVHOc':'./ajax.php?act=gettoolday','XyZJR':_0x4b0296(0x270,'HakZ'),'hvQra':function(_0x4dc2a9,_0x11a673){return _0x4dc2a9+_0x11a673;},'TxoHc':function(_0x4783d8,_0x41279a){return _0x4783d8!==_0x41279a;},'GtNIR':'wxrQW','JFNLA':'<div\x20class=\x22detail\x22\x20style=\x22height:unset;\x22>','NDYsq':_0x4b0296(0x15b,'opNi'),'tPqDV':_0x4b0296(0x28a,'FU1p'),'GPmtF':_0x4b0296(0x39b,'#@S]'),'NreKj':'<div><i\x20class=\x22layui-icon\x20layui-icon-time\x22></i>','dSVuL':'3|1|4|0|2','AfLJp':function(_0x2f1786,_0x5e7a80){return _0x2f1786+_0x5e7a80;},'ZgggW':'<div>\x20<i\x20class=\x22layui-icon\x20layui-icon-fire\x22\x20style=\x22font-size:10px;\x22></i>','kuyZM':_0x4b0296(0x248,'HakZ'),'wbiBh':'.tag_name\x20ul','uRbOE':function(_0x310a4e,_0x10843d){return _0x310a4e==_0x10843d;},'wLDFz':function(_0x1f9130,_0x1731aa){return _0x1f9130(_0x1731aa);},'slNKv':_0x4b0296(0x1d6,'ZNd*'),'XMadk':function(_0x4d8575,_0x2c7b8c){return _0x4d8575(_0x2c7b8c);},'pmWBm':'.catname_cc','hDYCO':function(_0x4b0bdf,_0x34167b){return _0x4b0bdf+_0x34167b;},'qFPaN':function(_0xf01c1a,_0x54d37a){return _0xf01c1a+_0x54d37a;},'hqZZf':_0x4b0296(0x3c9,'PkL)'),'EOaoY':function(_0x29bd57,_0x3115d8){return _0x29bd57+_0x3115d8;},'xAaPn':_0x4b0296(0x38a,'C*$M'),'hDfdb':_0x4b0296(0x34a,'$AV['),'CsxAD':_0x4b0296(0x1c7,'qVQ%'),'VabVw':function(_0x3a1113,_0x3e9ee9){return _0x3a1113<_0x3e9ee9;},'ZTLGq':_0x4b0296(0x31e,'0S%U'),'Oicwf':'Xyfwu','mAWOI':_0x4b0296(0x11e,'VYdb'),'wojlF':'input[name=kw]','FFSbx':_0x4b0296(0x2de,'QBxe'),'sADNi':'没有更多数据了','FOFiU':function(_0x170cd4,_0x4efa79){return _0x170cd4!=_0x4efa79;},'ojLIK':function(_0x25ca13){return _0x25ca13();},'uddRH':_0x4b0296(0x2ed,'Dz@M'),'cMUsa':_0x4b0296(0x207,'8Ssq'),'uNUbR':_0x4b0296(0x17f,'T$x)'),'TpRQB':_0x4b0296(0x356,'opNi'),'PddWU':function(_0x26b970,_0x3426c6){return _0x26b970==_0x3426c6;},'RNTac':_0x4b0296(0x2b9,'&8fr'),'FcYti':'flow'};$('#c'+_0x1543d)[_0x4b0296(0x1ae,'aNDp')](_0x19a767['uNUbR'])[_0x4b0296(0x407,'NTHj')]()['removeClass'](_0x19a767[_0x4b0296(0x154,'oHP&')]);var _0x1aa248=/(nokia|iphone|android|motorola|^mot-|softbank|foma|docomo|kddi|up.browser|up.link|htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte-|longcos|pantech|gionee|^sie-|portalmmm|jigs browser|hiptop|^benq|haier|^lct|operas*mobi|opera*mini|320x320|240x320|176x220)/i,_0x2e78a3=navigator[_0x4b0296(0x143,'@d#l')];if(_0x19a767['uRbOE'](null,_0x2e78a3)){if('SlBUZ'!==_0x19a767['TpRQB'])_0x3e4699='';else return!![];}var _0x45c1d0=_0x1aa248['exec'](_0x2e78a3);if(_0x19a767[_0x4b0296(0x3a9,'LD9J')](null,_0x45c1d0)){if(_0x19a767[_0x4b0296(0x382,'wCZK')](_0x4b0296(0x35f,'[Sw^'),_0x4b0296(0x276,'PkL)')))var _0x4fd259=0x1;else _0x2d881e='';}else{if(_0x4b0296(0x2ac,'$epu')===_0x4b0296(0x3ab,'$epu'))_0x4c5acc='';else var _0x4fd259=0x2;}_0x19a767[_0x4b0296(0x211,'hYEw')]($,_0x19a767[_0x4b0296(0x180,'8Ssq')])[_0x4b0296(0x410,'HakZ')](),_0x19a767['XMadk']($,_0x19a767[_0x4b0296(0x2a6,'wCZK')])[_0x4b0296(0x156,'[Sw^')](_0x4b0296(0x187,'#@S]')),layui[_0x4b0296(0x287,'@d#l')]([_0x19a767[_0x4b0296(0x280,'T$x)')]],function(){var _0x48af26=_0x4b0296,_0x4c22c8={'ICPlh':function(_0x2afb80,_0x4e03d5){return _0x2afb80-_0x4e03d5;},'xEQsf':function(_0x4183a1,_0x74be6d){return _0x4183a1(_0x74be6d);},'qNVHo':function(_0x19ee6f,_0x11a5d8){var _0xcebd76=_0x3916;return _0x19a767[_0xcebd76(0x179,'aNDp')](_0x19ee6f,_0x11a5d8);},'VWGvB':function(_0x5a3308,_0x136146){return _0x5a3308+_0x136146;},'fisnT':_0x19a767[_0x48af26(0x2f8,'aNDp')],'lHheK':'<div\x20class=\x22image\x22>','VTomA':function(_0x88ef2e,_0x230d35){return _0x19a767['TxoHc'](_0x88ef2e,_0x230d35);},'SMmle':'xPOxA','zLbEz':'fFkJH','OUgOX':_0x19a767[_0x48af26(0x32b,'HFJx')],'vsulV':'24小时全自动发货','qInZU':'SmsHm','nNEUL':_0x19a767[_0x48af26(0x31a,'P$4]')],'uWJeE':_0x19a767[_0x48af26(0x21e,'Xl4K')],'KugKj':_0x19a767[_0x48af26(0x393,'hYEw')],'yKeCW':'<div\x20class=\x22def2\x22></div>&nbsp;第','pyZMY':_0x19a767[_0x48af26(0x3e3,'opNi')],'dIxRQ':function(_0x23afa2,_0x4dc5d5){return _0x23afa2+_0x4dc5d5;},'XVfox':_0x48af26(0x1f9,'Xl4K'),'enZKB':_0x19a767[_0x48af26(0x408,'zLrg')],'sOIsZ':function(_0x3e893f,_0x1eb45c){return _0x19a767['Xefpw'](_0x3e893f,_0x1eb45c);},'iKruo':_0x48af26(0x1f4,'a*B!'),'PCJTT':_0x19a767[_0x48af26(0x405,'QBxe')],'XXhOg':_0x19a767[_0x48af26(0x2eb,'8Ssq')],'okFzz':function(_0x17bcfe,_0x2099c7){var _0x19e568=_0x48af26;return _0x19a767[_0x19e568(0x13b,'$epu')](_0x17bcfe,_0x2099c7);},'GfCBi':_0x19a767[_0x48af26(0x367,'(]Pj')],'fFEXr':_0x19a767[_0x48af26(0x119,'D2UO')],'FWLKS':_0x19a767[_0x48af26(0x1d5,'oHP&')],'KqVUf':_0x19a767[_0x48af26(0x2d0,'CdLa')],'xIffQ':function(_0x26b8c7,_0x9adae1){var _0x227b49=_0x48af26;return _0x19a767[_0x227b49(0x2e8,'hYEw')](_0x26b8c7,_0x9adae1);},'xwLsb':'etGqW','aOnHX':function(_0x5ad4c0,_0x2f9a68){var _0x2da853=_0x48af26;return _0x19a767[_0x2da853(0x125,'a*B!')](_0x5ad4c0,_0x2f9a68);},'UiZBM':_0x48af26(0x2f4,'HFJx'),'YYEIX':_0x19a767[_0x48af26(0x1ef,'8Ssq')],'ygIEx':function(_0x3174ce,_0x41d591){return _0x19a767['uRbOE'](_0x3174ce,_0x41d591);},'jXGGV':function(_0x46d607,_0x50b179){var _0x335e75=_0x48af26;return _0x19a767[_0x335e75(0x211,'hYEw')](_0x46d607,_0x50b179);},'qFfsP':_0x19a767[_0x48af26(0x171,'$AV[')],'mGvKe':_0x48af26(0x10d,'P$4]'),'wywHr':function(_0x351934,_0xc93701){var _0x2c4d10=_0x48af26;return _0x19a767[_0x2c4d10(0x3a5,'t!Kv')](_0x351934,_0xc93701);},'UjGZa':_0x19a767[_0x48af26(0x232,'PkL)')],'pskSI':function(_0xcec6f9,_0x26b9fa){var _0x325262=_0x48af26;return _0x19a767[_0x325262(0x2a5,'rQl!')](_0xcec6f9,_0x26b9fa);},'tmAXm':function(_0x48acc5,_0x2d5d38){return _0x19a767['qFPaN'](_0x48acc5,_0x2d5d38);},'kRUye':_0x19a767['hqZZf'],'hdGpH':function(_0x558e3a,_0x1858c7){return _0x558e3a+_0x1858c7;},'gvbAc':function(_0x1a4600,_0x245171){return _0x19a767['EOaoY'](_0x1a4600,_0x245171);},'ZZoXE':_0x19a767['xAaPn'],'eIUHF':_0x19a767[_0x48af26(0x33c,'rQl!')],'WwWlq':function(_0x2d0e14,_0x5eb905){return _0x2d0e14!=_0x5eb905;},'hpDSc':function(_0x50ae76,_0x370296){return _0x50ae76(_0x370296);},'yaFRL':function(_0x2ed260,_0x3a75c8){return _0x2ed260(_0x3a75c8);},'fFrND':function(_0x1d8411,_0xd518f3){var _0xbbff3d=_0x48af26;return _0x19a767[_0xbbff3d(0x170,'Dz@M')](_0x1d8411,_0xd518f3);},'rDQwt':_0x19a767[_0x48af26(0x2b7,'UV9o')],'IRRPT':function(_0x503e90,_0x1f90bb){return _0x503e90(_0x1f90bb);},'zSYty':function(_0x7d76b0,_0x2efd95){var _0x3617bf=_0x48af26;return _0x19a767[_0x3617bf(0x3f2,'Lu%g')](_0x7d76b0,_0x2efd95);}};if(_0x19a767[_0x48af26(0x313,'HakZ')]!==_0x19a767[_0x48af26(0x315,'%mAI')]){var _0xd0e87f=layui['flow'],_0x23e557=_0x19a767[_0x48af26(0x23c,'zLrg')]($,'input[name=_cid]')[_0x48af26(0x1b2,'HFJx')](),_0x59455f=$(_0x19a767['mAWOI'])[_0x48af26(0x19e,'8Ssq')](),_0x1d02d7=_0x19a767['XMadk']($,_0x19a767[_0x48af26(0x399,'opNi')])[_0x48af26(0x1f5,'FU1p')](),_0x4dc4f=$(_0x48af26(0x1f2,'2uOU'))[_0x48af26(0x19e,'8Ssq')](),_0x277289=_0x19a767[_0x48af26(0x2b6,'xass')]($,_0x48af26(0x196,'2uOU'))['val'](),_0x456f58=testUA(_0x19a767[_0x48af26(0x195,'qVQ%')])?0xb4:0x64,_0x422697=_0x1d02d7?_0x19a767[_0x48af26(0x283,'0gc9')]:'\x20';limit=0x64,_0x19a767['FOFiU'](_0x59455f,'')&&_0x19a767[_0x48af26(0x2b0,'gigD')](load),_0x19a767[_0x48af26(0x341,'2uOU')]($,_0x19a767[_0x48af26(0x384,'NTHj')])[_0x48af26(0x327,'xass')](),_0xd0e87f[_0x48af26(0x3bc,'rQl!')]({'elem':_0x19a767[_0x48af26(0x293,'0S%U')],'isAuto':!![],'mb':_0x456f58,'isLazyimg':!![],'end':_0x422697,'done':function(_0x45fc3f,_0x3b130c){var _0x323d68=_0x48af26,_0x6db838={'jnFEa':function(_0x4fb7be,_0x40de22){return _0x4fb7be+_0x40de22;},'FmrJM':_0x19a767[_0x323d68(0x39c,'Lu%g')],'llvEO':function(_0x50778f,_0x3bcc93){var _0x22fdb0=_0x323d68;return _0x19a767[_0x22fdb0(0x238,'UV9o')](_0x50778f,_0x3bcc93);},'EThok':_0x19a767[_0x323d68(0x3a3,'&8fr')],'zRcZN':_0x19a767['Imwyy'],'owUlt':_0x19a767[_0x323d68(0x1c9,'gigD')],'CujeQ':_0x323d68(0x352,'opNi'),'nNXNR':'#goods-list-container','oAnNW':_0x19a767[_0x323d68(0x33b,'8Ssq')],'gywJq':_0x323d68(0x1c1,'rQl!'),'TJcqF':function(_0x48e6ff,_0x5ca24b){return _0x19a767['XPnJY'](_0x48e6ff,_0x5ca24b);},'ZYfyD':function(_0x1c97a3,_0x1215cf){var _0x5a8779=_0x323d68;return _0x19a767[_0x5a8779(0x2e9,'2uOU')](_0x1c97a3,_0x1215cf);},'mrsDc':function(_0x3117da,_0x52d029){var _0x34885a=_0x323d68;return _0x19a767[_0x34885a(0x13a,'P$4]')](_0x3117da,_0x52d029);},'FYriP':_0x19a767['Botrm'],'hhVuq':_0x19a767['udYrQ'],'tzwnE':_0x19a767[_0x323d68(0x3a2,'xass')],'BceDb':function(_0x1d132a,_0x20010e){return _0x19a767['zVZic'](_0x1d132a,_0x20010e);},'KFuCr':function(_0x1a7d2d,_0x4b859a){var _0x9e5381=_0x323d68;return _0x19a767[_0x9e5381(0x2c3,'n9NZ')](_0x1a7d2d,_0x4b859a);},'LWEwo':'</span></p>','GJbkT':function(_0x4767d1,_0x46f73e){return _0x19a767['diqng'](_0x4767d1,_0x46f73e);},'AuHmT':_0x19a767['nsblN'],'wVVTw':function(_0x5da21d,_0x1c0c16){return _0x5da21d+_0x1c0c16;},'tFLFC':function(_0x201249,_0x1c03b8){return _0x201249+_0x1c03b8;},'iOPfe':_0x19a767['OiUcp'],'iTEAF':_0x323d68(0x266,'0gc9'),'dcebH':'<div\x20class=\x22detail\x22\x20style=\x22height:unset;\x22>','DObRy':function(_0x537074,_0x5ecfa5){return _0x537074+_0x5ecfa5;},'bCSSb':function(_0x43100e,_0x51fa45){var _0x215f13=_0x323d68;return _0x19a767[_0x215f13(0x1a3,'$AV[')](_0x43100e,_0x51fa45);},'yQcsT':_0x19a767[_0x323d68(0x3fe,'P$4]')],'JxpDy':_0x19a767['IMEIb'],'QhUMG':_0x323d68(0x253,'CdLa'),'SkfcC':function(_0x4e1d75,_0x5cf489){var _0xe0c536=_0x323d68;return _0x19a767[_0xe0c536(0x210,'HFJx')](_0x4e1d75,_0x5cf489);},'VMwrw':function(_0x220114,_0x2d90f1){var _0x49aaf5=_0x323d68;return _0x19a767[_0x49aaf5(0x175,'$epu')](_0x220114,_0x2d90f1);},'vSOkL':'agWmA','UsFXV':_0x323d68(0x31c,'aNDp'),'TjFIw':function(_0x5dceee,_0x52fc1d){var _0x557c26=_0x323d68;return _0x19a767[_0x557c26(0x1e2,'opNi')](_0x5dceee,_0x52fc1d);},'xkTwk':_0x19a767[_0x323d68(0x233,'opNi')],'cnytG':_0x323d68(0x278,'T$x)'),'vtbWT':_0x19a767[_0x323d68(0x217,'VYdb')],'OhDmT':function(_0x2c4c35,_0x494159){var _0x434eac=_0x323d68;return _0x19a767[_0x434eac(0x107,'UV9o')](_0x2c4c35,_0x494159);},'nweur':_0x19a767[_0x323d68(0x37f,'P$4]')],'GyRbO':_0x19a767[_0x323d68(0x1b5,'(]Pj')],'umgoO':function(_0xa98654,_0x1fe408){return _0x19a767['tfKKu'](_0xa98654,_0x1fe408);},'bVEkI':'<div\x20class=\x22rob_st\x22><img\x20src=\x22../assets/img/rob_icon2.png\x22\x20style=\x22width:\x20100%;height:\x20100%;\x22></div>','SKoEq':function(_0xe3a9b5,_0x31cf07){return _0x19a767['vLyyE'](_0xe3a9b5,_0x31cf07);},'CILGF':function(_0x3672a5,_0x343ff3){var _0x191cb4=_0x323d68;return _0x19a767[_0x191cb4(0x26a,'xass')](_0x3672a5,_0x343ff3);},'MrKhr':_0x19a767['MRjmN'],'PFBQl':_0x19a767[_0x323d68(0x312,'a*B!')],'XRFcl':_0x19a767[_0x323d68(0x1b4,'VYdb')],'ANDXR':_0x323d68(0x38f,'HFJx')};if(_0x323d68(0x333,'Dz@M')!==_0x19a767[_0x323d68(0x282,'0S%U')])_0x302a76='<div\x20class=\x22rob_st\x22><img\x20src=\x22../assets/img/rob_icon5.png\x22\x20style=\x22width:\x20100%;height:\x20100%;\x22></div>';else{var _0x28658e=[];$[_0x323d68(0x376,'NTHj')]({'type':_0x19a767[_0x323d68(0x3e7,'(]Pj')],'url':_0x19a767[_0x323d68(0x1d3,'T$x)')],'data':{'page':_0x45fc3f,'limit':limit,'cid':_0x23e557,'kw':_0x1d02d7,'sort_type':_0x4dc4f,'sort':_0x277289,'time':_0x429735},'dataType':_0x19a767[_0x323d68(0x2d7,'xass')],'success':function(_0x5828f3){var _0x3bd19e=_0x323d68,_0x4841e3={'ZeKyj':function(_0x4f3b8c,_0x471fdf){return _0x4f3b8c<=_0x471fdf;},'qgBUf':function(_0x58c13d,_0x5a4c63){return _0x4c22c8['ICPlh'](_0x58c13d,_0x5a4c63);},'ybCpe':function(_0x876b80,_0x298ca1){return _0x4c22c8['xEQsf'](_0x876b80,_0x298ca1);},'CruNk':function(_0x5484fb,_0x26a67a){return _0x5484fb==_0x26a67a;},'dxTjI':function(_0xe8f601,_0x320e76){var _0x29b034=_0x3916;return _0x4c22c8[_0x29b034(0x3ae,'hYEw')](_0xe8f601,_0x320e76);},'tvpVl':function(_0x6e2f49,_0x1fda20){var _0x57bd95=_0x3916;return _0x4c22c8[_0x57bd95(0x198,'Xl4K')](_0x6e2f49,_0x1fda20);},'lTsxv':function(_0x201c67,_0x49f49a){var _0x2aac3a=_0x3916;return _0x4c22c8[_0x2aac3a(0x1ac,'0S%U')](_0x201c67,_0x49f49a);},'PEBcp':_0x4c22c8[_0x3bd19e(0x106,'rQl!')],'JjPGK':_0x4c22c8[_0x3bd19e(0x14a,'xass')],'peacU':function(_0x2ba259,_0x31c0cd){var _0x5eef4a=_0x3bd19e;return _0x4c22c8[_0x5eef4a(0x2f9,'n9NZ')](_0x2ba259,_0x31c0cd);},'Kncuk':_0x4c22c8[_0x3bd19e(0x30f,'Xl4K')],'ucJRG':_0x4c22c8[_0x3bd19e(0x174,'rQl!')],'xylnh':'./assets/store/picture/error_img.png','AtVlp':_0x4c22c8[_0x3bd19e(0x123,'NTHj')],'UmVdV':_0x4c22c8[_0x3bd19e(0x391,'Ngkf')],'vKgCA':_0x4c22c8['qInZU'],'wDGHZ':function(_0x131415,_0x2b5d3a){return _0x131415>_0x2b5d3a;},'Lhsmb':function(_0xcc61c8,_0x5aa218){return _0xcc61c8+_0x5aa218;},'qTvrQ':function(_0x529ef,_0x5a1d9f){return _0x4c22c8['qNVHo'](_0x529ef,_0x5a1d9f);},'sGbfP':_0x3bd19e(0x266,'0gc9'),'iojEw':_0x4c22c8[_0x3bd19e(0x34c,'%mAI')],'CwyNz':_0x4c22c8['uWJeE'],'HbKYB':function(_0xd435fb,_0x410d15){return _0xd435fb+_0x410d15;},'UbYMA':_0x4c22c8['KugKj'],'IAKoL':function(_0x48aca9,_0x44e442){var _0xa44787=_0x3bd19e;return _0x4c22c8[_0xa44787(0x2cd,'a*B!')](_0x48aca9,_0x44e442);},'KvdUY':_0x4c22c8[_0x3bd19e(0x2c8,'HakZ')],'QZSuO':_0x4c22c8[_0x3bd19e(0xf9,'UV9o')],'JsbiU':function(_0x35104f,_0x5c374d){return _0x35104f==_0x5c374d;},'hgpQu':function(_0x2590d9,_0x5dcc58){return _0x4c22c8['dIxRQ'](_0x2590d9,_0x5dcc58);},'lNhSI':'<div\x20style=\x22color:\x20#888;height:40px;font-size:.6rem;margin-top:\x205px;\x22>','GXirm':_0x4c22c8[_0x3bd19e(0x18a,'Dz@M')],'PTVtg':_0x4c22c8['enZKB'],'WxDYr':function(_0x5e6f84,_0x53059d){var _0x134f5e=_0x3bd19e;return _0x4c22c8[_0x134f5e(0x25d,'VYdb')](_0x5e6f84,_0x53059d);},'rtmTD':_0x4c22c8['iKruo'],'xaKtf':_0x4c22c8[_0x3bd19e(0x2e6,'NTHj')],'mEUxk':function(_0x1889d6,_0x555a2d){return _0x1889d6+_0x555a2d;},'lQmsb':function(_0x37f0d7,_0x3f35de){return _0x37f0d7+_0x3f35de;},'PbDAI':_0x3bd19e(0x128,'aNDp'),'MkAaK':_0x4c22c8['XXhOg'],'Outbe':function(_0x485516,_0x4dc488){return _0x485516+_0x4dc488;},'sSHDt':'<div><i\x20class=\x22layui-icon\x20layui-icon-rmb\x22></i>','LDGUi':function(_0xb784c7,_0x398cb1){return _0x4c22c8['okFzz'](_0xb784c7,_0x398cb1);},'neIUb':'<div\x20style=\x22display:\x20flex;margin-top:5px;\x20justify-content:\x20space-between;\x22>','kDuEU':function(_0x4c2506,_0x107a48){return _0x4c22c8['dIxRQ'](_0x4c2506,_0x107a48);},'vGwVu':_0x4c22c8[_0x3bd19e(0x3c7,'C*$M')],'svMyV':_0x4c22c8[_0x3bd19e(0x2a9,'PkL)')],'yqTYX':_0x3bd19e(0x1c3,'NTHj'),'mbFJc':_0x4c22c8[_0x3bd19e(0x36f,'[Sw^')],'UGZmS':function(_0x34bd1a,_0x512741){return _0x34bd1a(_0x512741);},'QFGvt':_0x3bd19e(0x203,'D2UO'),'hMgEt':_0x4c22c8['KqVUf']};if(_0x4c22c8[_0x3bd19e(0x1ea,'S)(1')](_0x4c22c8[_0x3bd19e(0x255,'gigD')],_0x4c22c8[_0x3bd19e(0x32a,'Lu%g')]))_0x395290=_0x6db838['jnFEa'](_0x3bd19e(0x3f4,'@d#l'),_0x1f530d[_0x3bd19e(0x2be,'Lu%g')])+_0x3bd19e(0x359,'opNi');else{_0x4c22c8['aOnHX']($,_0x4c22c8['UiZBM'])[_0x3bd19e(0x2f0,'P$4]')](),_0x4c22c8[_0x3bd19e(0x34b,'wCZK')]($,_0x4c22c8['YYEIX'])['html'](''),console[_0x3bd19e(0x1eb,'$epu')](_0x5828f3);var _0x1764bc='';_0x4c22c8[_0x3bd19e(0x274,'NTHj')](_0x5828f3['bb'],'2')?layui[_0x3bd19e(0x381,'CdLa')](_0x5828f3[_0x3bd19e(0x275,'HFJx')],function(_0x9f5532,_0x3438ae){var _0x3e78ca=_0x3bd19e,_0x594a4d={'guDkW':function(_0xb02f4e,_0x2b0435){var _0x46ae4e=_0x3916;return _0x4841e3[_0x46ae4e(0x3e6,'gigD')](_0xb02f4e,_0x2b0435);},'kDbGS':function(_0x587e52,_0x7ce8f0){var _0xec8990=_0x3916;return _0x4841e3[_0xec8990(0x39f,'HFJx')](_0x587e52,_0x7ce8f0);},'oXsIo':function(_0x2d8e5c,_0x4fa6e5){return _0x2d8e5c(_0x4fa6e5);},'jEzoi':_0x3e78ca(0x3bf,'wCZK')};_0x1764bc=_0x4841e3['dxTjI'](_0x4841e3[_0x3e78ca(0x181,'oHP&')](_0x4841e3[_0x3e78ca(0x146,'hYEw')](_0x4841e3[_0x3e78ca(0x3d8,'UV9o')],_0x3438ae[_0x3e78ca(0x10f,'xass')])+_0x3e78ca(0x330,'aNDp'),_0x3438ae[_0x3e78ca(0x28b,'FU1p')]),'\x22>'),_0x1764bc+=_0x4841e3['JjPGK'];!_0x3438ae[_0x3e78ca(0x208,'PkL)')]&&(_0x4841e3[_0x3e78ca(0x3b4,'PkL)')](_0x4841e3[_0x3e78ca(0x1ab,'Lu%g')],_0x4841e3[_0x3e78ca(0x2e5,'a*B!')])?_0x3438ae[_0x3e78ca(0x3bb,'gigD')]=_0x4841e3[_0x3e78ca(0x2a0,'0gc9')]:_0x4841e3['ZeKyj'](_0x4841e3[_0x3e78ca(0x395,'UV9o')](_0x2f982c,_0x28a10c['addtime']),0x3f480)?_0x1c8bd6='':_0x1cfb7f='');_0x3438ae[_0x3e78ca(0x3d3,'[Sw^')]?show_tag=_0x3438ae[_0x3e78ca(0x16f,'T$x)')]:_0x4841e3[_0x3e78ca(0x16d,'Ngkf')](_0x4841e3['qgBUf'](curr_time,_0x3438ae['addtime']),0x240c8400)?show_tag='':show_tag='';show_tag_html='';if(show_tag){if(_0x4841e3[_0x3e78ca(0x155,'JxJO')]!==_0x3e78ca(0x3b0,'ZNd*'))show_tag_html='';else{var _0x524f41=_0x594a4d['guDkW'](_0x5ecb63,_0x24e69b)[_0x3e78ca(0x2b8,'0gc9')](_0x3e78ca(0x3ba,'$AV[')),_0x5c5737=_0x4297c2[_0x3e78ca(0x224,'HakZ')](_0x3c3fa8);_0x594a4d[_0x3e78ca(0x3cb,'JxJO')](_0x524f41,'on')?_0x594a4d[_0x3e78ca(0x200,'0gc9')](_0x1a95e0,_0x1a5a43)['removeClass']('on')[_0x3e78ca(0x2d9,'@d#l')](_0x3e78ca(0x388,'@d#l')):_0x418d39(_0x26aa6a)[_0x3e78ca(0x342,'JxJO')](_0x594a4d['jEzoi'])[_0x3e78ca(0x3f9,'a*B!')]('on'),_0x524f41=='on'?_0x5c5737['pause']():_0x5c5737[_0x3e78ca(0x1cc,'&8fr')]();}}var _0x40090a='',_0x425810=_0x4841e3['UmVdV'];_0x3438ae['is_stock_err']==0x1&&(_0x4841e3[_0x3e78ca(0x17a,'a*B!')]!==_0x4841e3[_0x3e78ca(0x301,'eyQr')]?_0x5d1048=_0x3e78ca(0x305,'HFJx'):_0x40090a='');_0x4841e3['wDGHZ'](_0x3438ae[_0x3e78ca(0x27d,'xass')],0x0)&&(_0x425810=_0x4841e3[_0x3e78ca(0x188,'0gc9')]);_0x1764bc+=_0x4841e3[_0x3e78ca(0x219,'QBxe')](_0x4841e3[_0x3e78ca(0x1e6,'t!Kv')](_0x4841e3[_0x3e78ca(0x404,'Ngkf')](_0x4841e3[_0x3e78ca(0x31f,'gigD')](_0x4841e3['dxTjI'](_0x4841e3[_0x3e78ca(0x337,'0S%U')]('',show_tag_html)+'<img\x20class=\x22lazy\x22\x20lay-src=\x22',_0x3438ae[_0x3e78ca(0x23e,'QBxe')]),_0x4841e3[_0x3e78ca(0x152,'hYEw')]),_0x3438ae[_0x3e78ca(0x1f8,'8Ssq')]),'\x22>')+_0x40090a,''),_0x1764bc+=_0x4841e3[_0x3e78ca(0x19d,'C*$M')],_0x1764bc+=_0x4841e3['CwyNz'],_0x1764bc+=_0x4841e3[_0x3e78ca(0x339,'oHP&')](_0x4841e3['dxTjI'](_0x4841e3[_0x3e78ca(0x351,'LD9J')],_0x3438ae[_0x3e78ca(0x260,'aNDp')]),_0x3e78ca(0x115,'LD9J'));_0x4841e3[_0x3e78ca(0x3f0,'he#0')](_0x3438ae['v'],0x1)&&(_0x1764bc+=_0x4841e3[_0x3e78ca(0x3ec,'UV9o')](_0x4841e3['KvdUY']+_0x3438ae[_0x3e78ca(0x29f,'NTHj')],'期'));_0x1764bc+=_0x4841e3[_0x3e78ca(0x173,'a*B!')],_0x1764bc+=_0x4841e3[_0x3e78ca(0xf8,'$epu')](_0x4841e3[_0x3e78ca(0x2db,'qVQ%')]+_0x3438ae[_0x3e78ca(0x2ca,'CdLa')],_0x4841e3[_0x3e78ca(0x124,'FU1p')]);_0x4841e3[_0x3e78ca(0x30c,'UV9o')](_0x3438ae['isdesc'],0x2)&&(_0x1764bc+=_0x4841e3[_0x3e78ca(0x22b,'Dz@M')](_0x4841e3[_0x3e78ca(0x297,'Dz@M')]+_0x3438ae[_0x3e78ca(0x1aa,'HakZ')],''),_0x1764bc+=_0x4841e3['iojEw']);var _0xbf86a7=_0x4841e3['hgpQu'](_0x4841e3['GXirm'],_0x3438ae['price'])+_0x4841e3[_0x3e78ca(0x1db,'Ngkf')];_0x4841e3[_0x3e78ca(0x311,'HakZ')](_0x3438ae[_0x3e78ca(0x29c,'PkL)')],0x0)&&(_0xbf86a7='<p\x20class=\x22minprice\x22\x20style=\x22font-size:.75rem;\x22>免费领取</p>');_0x1764bc+='',console['log'](_0x4fd259);if(_0x4fd259=='1')_0x1764bc+=_0x4841e3[_0x3e78ca(0x325,'4]lE')],_0x1764bc+=_0x4841e3[_0x3e78ca(0x2b1,'0S%U')](_0x4841e3[_0x3e78ca(0x373,'Dz@M')](_0x4841e3['xaKtf'],_0x3438ae['time']),_0x4841e3[_0x3e78ca(0x102,'xass')]),_0x1764bc+=_0x4841e3[_0x3e78ca(0x2f2,'he#0')](_0x3e78ca(0xfb,'CdLa')+_0x3438ae['sales'],_0x4841e3['iojEw']),_0x1764bc+=_0x4841e3[_0x3e78ca(0x181,'oHP&')](_0x4841e3['lQmsb'](_0x4841e3[_0x3e78ca(0x1cf,'eyQr')],_0x3438ae['price']),_0x4841e3[_0x3e78ca(0x240,'VYdb')]),_0x1764bc+=_0x4841e3[_0x3e78ca(0x2f5,'PkL)')];else{if(_0x4841e3[_0x3e78ca(0x2ec,'8Ssq')](_0x4fd259,'2')){var _0x10147e=_0x4841e3[_0x3e78ca(0x1cb,'FU1p')][_0x3e78ca(0x35b,'2uOU')]('|'),_0x408372=0x0;while(!![]){switch(_0x10147e[_0x408372++]){case'0':_0x1764bc+=_0x4841e3[_0x3e78ca(0x129,'[Sw^')](_0x4841e3[_0x3e78ca(0x189,'eyQr')](_0x4841e3[_0x3e78ca(0x2ee,'#@S]')],_0x3438ae[_0x3e78ca(0x27c,'wCZK')]),_0x4841e3['iojEw']);continue;case'1':_0x1764bc+=_0x4841e3['LDGUi'](_0x4841e3['HbKYB'](_0x3e78ca(0x139,'rQl!'),_0x3438ae[_0x3e78ca(0x117,'t!Kv')]),_0x4841e3[_0x3e78ca(0x2ad,'LD9J')]);continue;case'2':_0x1764bc+=_0x4841e3[_0x3e78ca(0x240,'VYdb')];continue;case'3':_0x1764bc+=_0x4841e3[_0x3e78ca(0x298,'LD9J')];continue;case'4':_0x1764bc+=_0x4841e3[_0x3e78ca(0x40c,'P$4]')](_0x4841e3[_0x3e78ca(0x1c8,'5zi5')],_0x3438ae[_0x3e78ca(0x21f,'wCZK')])+_0x3e78ca(0x300,'S)(1');continue;}break;}}}_0x1764bc+=_0x4841e3['iojEw'],_0x1764bc+=_0x3e78ca(0x234,'$epu'),_0x28658e['push'](_0x1764bc);}):layui['each'](_0x5828f3[_0x3bd19e(0x3f8,'$epu')],function(_0x20b81c,_0x5c6b41){var _0x4f11b8=_0x3bd19e,_0x215ebb={'HxKFh':_0x6db838[_0x4f11b8(0x2b5,'a*B!')],'OvZIu':function(_0x152b6e,_0x2d3d24){var _0x200842=_0x4f11b8;return _0x6db838[_0x200842(0x256,'S)(1')](_0x152b6e,_0x2d3d24);},'tsliq':function(_0x3349ef,_0x2eff6a){return _0x3349ef==_0x2eff6a;},'sHtnx':_0x6db838[_0x4f11b8(0x244,'hYEw')],'cJUvJ':_0x6db838[_0x4f11b8(0x162,'$epu')],'czTYR':function(_0x41a1d1,_0x212a1c){var _0x47649f=_0x4f11b8;return _0x6db838[_0x47649f(0x1a6,'JxJO')](_0x41a1d1,_0x212a1c);},'ZCJHG':_0x6db838['owUlt'],'Ijzvs':_0x6db838[_0x4f11b8(0x3a8,'ZNd*')],'uYuIO':_0x6db838[_0x4f11b8(0x265,'n9NZ')],'JSdck':function(_0x5acbfd,_0x48a512){return _0x6db838['llvEO'](_0x5acbfd,_0x48a512);},'kHuza':_0x6db838['oAnNW'],'rEeOy':'goods_list_style','pBkbt':_0x6db838[_0x4f11b8(0x11f,'rQl!')]};_0x1764bc=_0x6db838['TJcqF'](_0x6db838[_0x4f11b8(0x2ef,'8Ssq')](_0x6db838['mrsDc'](_0x6db838[_0x4f11b8(0x37a,'t!Kv')],_0x5c6b41['name']),_0x6db838[_0x4f11b8(0x193,'qVQ%')])+_0x5c6b41[_0x4f11b8(0x2fa,'rQl!')],'\x22>'),_0x1764bc+=_0x4f11b8(0x1a0,'#@S]');!_0x5c6b41['shopimg']&&(_0x5c6b41[_0x4f11b8(0x1ba,'FU1p')]=_0x6db838[_0x4f11b8(0x1e8,'&8fr')]);_0x5c6b41[_0x4f11b8(0x3c1,'Lu%g')]?show_tag=_0x5c6b41[_0x4f11b8(0x3ac,'HakZ')]:_0x6db838['BceDb'](curr_time,_0x5c6b41[_0x4f11b8(0x2ff,'Dz@M')])<=0x3f480?show_tag='':show_tag='';show_tag_html='';show_tag&&(show_tag_html='');var _0x3662f9='',_0x3665cb;_0x6db838[_0x4f11b8(0x377,'QBxe')](_0x5c6b41[_0x4f11b8(0x3f5,'rQl!')],0x0)?_0x3665cb=_0x4f11b8(0x3c6,'QBxe'):_0x3665cb=_0x6db838['ZYfyD'](_0x6db838['mrsDc'](_0x4f11b8(0x289,'he#0'),_0x5c6b41['price']),_0x6db838[_0x4f11b8(0x3c8,'Xl4K')]);_0x5c6b41['is_stock_err']==0x1&&(_0x6db838[_0x4f11b8(0x17e,'%mAI')](_0x6db838[_0x4f11b8(0x135,'opNi')],_0x4f11b8(0x149,'0S%U'))?_0x3662f9='':(_0xbae847(_0x4841e3[_0x4f11b8(0x3a1,'t!Kv')])[_0x4f11b8(0x3d9,'P$4]')](_0x4841e3[_0x4f11b8(0xff,'qVQ%')],_0x4841e3[_0x4f11b8(0x3df,'LD9J')]),_0x4841e3[_0x4f11b8(0x1f6,'HakZ')](_0x2b61c1,_0x4f11b8(0x3b5,'xass'))[_0x4f11b8(0x27a,'S)(1')](_0x4f11b8(0x3aa,'4]lE')),_0x4841e3[_0x4f11b8(0x3fd,'opNi')](_0x463aab,_0x4841e3[_0x4f11b8(0x2da,'2uOU')])[_0x4f11b8(0x307,'qVQ%')](_0x4841e3[_0x4f11b8(0x358,'gigD')]),_0x4841e3['ybCpe'](_0x50bb0d,_0x4f11b8(0x374,'@d#l'))['removeClass'](_0x4841e3[_0x4f11b8(0x111,'NTHj')])));_0x1764bc+=_0x6db838['jnFEa'](_0x6db838[_0x4f11b8(0x3e0,'HakZ')](_0x6db838['tFLFC'](_0x6db838[_0x4f11b8(0x380,'0gc9')]('',show_tag_html),_0x6db838[_0x4f11b8(0x167,'%mAI')])+_0x5c6b41[_0x4f11b8(0x3e9,'2uOU')]+_0x6db838[_0x4f11b8(0x35a,'T$x)')]+_0x5c6b41['name']+'\x22>',_0x3662f9),''),_0x1764bc+=_0x4f11b8(0x28d,'$epu'),_0x1764bc+=_0x6db838[_0x4f11b8(0x28e,'HakZ')],_0x1764bc+=_0x6db838[_0x4f11b8(0x3d5,'0gc9')](_0x6db838[_0x4f11b8(0x205,'UV9o')](_0x6db838[_0x4f11b8(0x3d1,'qVQ%')],_0x5c6b41[_0x4f11b8(0x347,'0gc9')]),_0x6db838[_0x4f11b8(0x2f3,'gigD')]),_0x1764bc+=_0x6db838[_0x4f11b8(0x269,'oHP&')];var _0xc52cc5='';_0x6db838[_0x4f11b8(0xfc,'FU1p')](_0x5c6b41[_0x4f11b8(0x3f5,'rQl!')],0x0)&&(_0x6db838['VMwrw'](_0x6db838['vSOkL'],_0x6db838[_0x4f11b8(0x324,'gigD')])?_0xc52cc5='':_0x1a1f6a=_0x2688b1[_0x4f11b8(0x14d,'PkL)')]);_0x1764bc+='';if(_0x6db838[_0x4f11b8(0x320,'n9NZ')](_0x5c6b41['price'],0x0))buy=_0x6db838[_0x4f11b8(0x14e,'FU1p')];else{if(_0x6db838['VMwrw'](_0x4f11b8(0x3a4,'&8fr'),_0x6db838[_0x4f11b8(0x3a6,'QBxe')]))buy=_0x6db838[_0x4f11b8(0x3d2,'0S%U')];else{var _0x57bb0e=_0x5eb761[_0x4f11b8(0x37e,'xass')](_0x215ebb[_0x4f11b8(0x1c5,'Lu%g')],{'icon':0x10,'shade':0.01}),_0x37eb38=_0x215ebb['OvZIu'](_0x286a73,this)['data'](_0x4f11b8(0x38e,'$epu'));_0x215ebb['tsliq'](_0x37eb38,_0x215ebb[_0x4f11b8(0x2d1,'HFJx')])?(_0x3b204c(this)[_0x4f11b8(0x1b0,'oHP&')](_0x215ebb[_0x4f11b8(0x1dc,'n9NZ')],_0x4f11b8(0x150,'(]Pj')),_0x215ebb[_0x4f11b8(0x18b,'4]lE')](_0x2aed5a,this)[_0x4f11b8(0x15a,'Lu%g')](_0x215ebb['ZCJHG']),_0x215ebb[_0x4f11b8(0x2c2,'0S%U')](_0x18cdf2,this)[_0x4f11b8(0x13d,'(]Pj')](_0x215ebb[_0x4f11b8(0x1dd,'JxJO')]),_0x215ebb[_0x4f11b8(0x3d7,'D2UO')](_0x4e47ab,_0x215ebb['uYuIO'])[_0x4f11b8(0x2fe,'t!Kv')]('block\x20three')):(_0x21c1c6(this)['data'](_0x4f11b8(0x328,'C*$M'),_0x215ebb[_0x4f11b8(0x177,'Lu%g')]),_0x215ebb[_0x4f11b8(0x18b,'4]lE')](_0x247596,this)[_0x4f11b8(0x11b,'&8fr')]('icon-sort'),_0x215ebb[_0x4f11b8(0x1c0,'UV9o')](_0x13ec76,this)[_0x4f11b8(0x307,'qVQ%')](_0x215ebb[_0x4f11b8(0x2d5,'@d#l')]),_0x215ebb[_0x4f11b8(0x3f6,'5zi5')](_0x2ea0cc,'#goods-list-container')[_0x4f11b8(0x15a,'Lu%g')](_0x215ebb[_0x4f11b8(0x225,'gigD')]));var _0x6edb30=new _0xd99184();_0x6edb30[_0x4f11b8(0x1e0,'CdLa')](_0x6edb30['getTime']()+0x15180),_0x236177['cookie'](_0x215ebb['rEeOy'],_0x37eb38,{'expires':_0x6edb30}),_0x3caa9b['close'](_0x57bb0e);}}_0x6db838['KFuCr'](_0x5c6b41[_0x4f11b8(0x24d,'T$x)')],0x0)&&(_0x6db838[_0x4f11b8(0x1df,'0gc9')](_0x4f11b8(0x122,'[Sw^'),_0x6db838['nweur'])?(_0x3b5337(_0x215ebb[_0x4f11b8(0x2b2,'HFJx')])[_0x4f11b8(0x23b,'opNi')](),_0x292988[_0x4f11b8(0x3b3,'D2UO')]('op',![],{'expires':0x1})):buy=_0x6db838[_0x4f11b8(0x26b,'he#0')]),_0x6db838['umgoO'](_0x5c6b41[_0x4f11b8(0x20f,'#@S]')],0x1)&&(buy=_0x6db838[_0x4f11b8(0x190,'@d#l')]),_0x1764bc+=_0x6db838[_0x4f11b8(0x1fb,'D2UO')](_0x6db838[_0x4f11b8(0x127,'oHP&')](_0x6db838[_0x4f11b8(0x390,'zLrg')](_0x6db838['MrKhr'],_0x3665cb),_0x6db838['PFBQl']),buy)+'</div>',_0x1764bc+=_0x4f11b8(0xfe,'#@S]'),_0x1764bc+=_0x6db838[_0x4f11b8(0x27f,'HFJx')],_0x28658e['push'](_0x1764bc);});if(_0x4c22c8['ygIEx'](_0x23e557,''))_0x4c22c8['jXGGV']($,_0x4c22c8['qFfsP'])[_0x3bd19e(0x108,'ZNd*')](),_0x4c22c8[_0x3bd19e(0x336,'P$4]')]($,_0x4c22c8['mGvKe'])[_0x3bd19e(0x361,'a*B!')](),_0x4c22c8[_0x3bd19e(0x331,'eyQr')]($,_0x4c22c8[_0x3bd19e(0x228,'CdLa')])[_0x3bd19e(0x34d,'&8fr')](),_0x4c22c8[_0x3bd19e(0x3f1,'JxJO')]($,_0x4c22c8[_0x3bd19e(0x2a7,'Lu%g')])['html'](_0x4c22c8['pskSI'](_0x4c22c8['tmAXm']('系统共有<font\x20style=\x22color:\x20#7d7c7a;font-size:\x2012px;\x22>',_0x5828f3[_0x3bd19e(0x40a,'a*B!')]),_0x4c22c8[_0x3bd19e(0x2c6,'t!Kv')]));else _0x59455f!=''&&(_0x4c22c8[_0x3bd19e(0x268,'8Ssq')]($,_0x3bd19e(0x272,'gigD'))[_0x3bd19e(0x25c,'HakZ')](),_0x4c22c8[_0x3bd19e(0x1ad,'[Sw^')]($,_0x3bd19e(0x29a,'$AV['))[_0x3bd19e(0x40e,'[Sw^')](),$(_0x3bd19e(0x261,'JxJO'))[_0x3bd19e(0x302,'S)(1')](),$(_0x3bd19e(0x133,'T$x)'))['html'](_0x4c22c8[_0x3bd19e(0x24a,'PkL)')](_0x4c22c8[_0x3bd19e(0x1b6,'HFJx')](_0x4c22c8[_0x3bd19e(0xfd,'VYdb')]+_0x59455f,_0x3bd19e(0x1b8,'#@S]'))+_0x5828f3['total'],_0x4c22c8['eIUHF'])));_0x4c22c8[_0x3bd19e(0x229,'NTHj')](_0x1d02d7,'')&&(_0x4c22c8['hpDSc']($,_0x3bd19e(0x169,'8Ssq'))[_0x3bd19e(0x168,'Ngkf')](),_0x4c22c8[_0x3bd19e(0x348,'QBxe')]($,_0x4c22c8[_0x3bd19e(0x27b,'P$4]')])[_0x3bd19e(0x11a,'0S%U')](),_0x4c22c8[_0x3bd19e(0x1be,'n9NZ')]($,_0x4c22c8[_0x3bd19e(0x239,'UV9o')])[_0x3bd19e(0x302,'S)(1')](),$('.catname_show')[_0x3bd19e(0x2e7,'$AV[')](_0x4c22c8['gvbAc'](_0x4c22c8[_0x3bd19e(0x20b,'#@S]')]('共有<font\x20style=\x22\x22>',_0x5828f3[_0x3bd19e(0x185,'$epu')]),_0x4c22c8['rDQwt']))),layer['closeAll'](),_0x4c22c8[_0x3bd19e(0xfa,'QBxe')]($,_0x3bd19e(0x262,'FU1p'))['text'](_0x5828f3['total']),_0x3b130c(_0x28658e['join'](''),_0x4c22c8[_0x3bd19e(0x3de,'D2UO')](_0x45fc3f,_0x5828f3[_0x3bd19e(0x322,'#@S]')]));}},'error':function(_0x15b210){var _0x21cf9f=_0x323d68;return layer['msg'](_0x6db838['ANDXR']),layer[_0x21cf9f(0x136,'Xl4K')](index),![];}});}}});}else _0x27001f[_0x48af26(0x183,'UV9o')]=_0x19a767[_0x48af26(0x40f,'Ngkf')];});}var audio_init={'changeClass':function(_0x4c1471,_0x1bb786){var _0x30704b=_0xae6a7,_0xd5c42={'SQyPa':'class','nJjia':_0x30704b(0x3bf,'wCZK'),'HsFwT':function(_0x25d24c,_0x246907){return _0x25d24c(_0x246907);},'rMvCn':function(_0x133c38,_0x551173){return _0x133c38==_0x551173;}},_0x4ea1f2=$(_0x4c1471)[_0x30704b(0x3f3,'Dz@M')](_0xd5c42[_0x30704b(0x2fb,'4]lE')]),_0x4bb0f4=document[_0x30704b(0x3ca,'$AV[')](_0x1bb786);_0x4ea1f2=='on'?$(_0x4c1471)['removeClass']('on')[_0x30704b(0x2bc,'0gc9')](_0xd5c42['nJjia']):_0xd5c42[_0x30704b(0x19a,'zLrg')]($,_0x4c1471)['removeClass'](_0x30704b(0x105,'#@S]'))[_0x30704b(0x35e,'$epu')]('on'),_0xd5c42[_0x30704b(0x36b,'CdLa')](_0x4ea1f2,'on')?_0x4bb0f4['pause']():_0x4bb0f4['play']();},'play':function(){var _0x428bcf=_0xae6a7,_0x2f3607={'wLjAj':'media'};document[_0x428bcf(0x246,'rQl!')](_0x2f3607[_0x428bcf(0x109,'PkL)')])[_0x428bcf(0x1ff,'[Sw^')]();}};$(_0xae6a7(0x3c0,'[Sw^'))['is'](_0xae6a7(0x209,'Lu%g'))&&audio_init[_0xae6a7(0x3bd,'%mAI')]();var version_ = 'jsjiami.com.v7';
</script>