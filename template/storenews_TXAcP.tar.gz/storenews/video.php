<?php
if (!defined('IN_CRONLITE')) die();
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./user/login.php';</script>");
$get = $_GET;
if(isset($get['id']) && !empty($get['id'])){
    $id = $get['id'];
    $videolist = $DB->getRow("SELECT * FROM `pre_videolist` WHERE id='$id' LIMIT 1");
    $price_obj = new \lib\Price($userrow['zid'], $userrow);
    $price_obj->setVideoInfo($id, $videolist);
    $price = $price_obj->getVideoPrice($id);
    $bfprice = $price_obj->getbfVideoPrice($id);
    $pay_url_log = $DB->getRow("SELECT * FROM `pre_orders` WHERE vid=" . $id . " AND input2='购买短剧地址' AND userid=" . $userrow['zid'] . " AND status=1 LIMIT 1");
    
    $pay_play_log = $DB->getRow("SELECT * FROM `pre_orders` WHERE vid=" . $id . " AND input2='购买短剧播放' AND input3='all' AND userid=" . $userrow['zid'] . " AND status=1 LIMIT 1");
    
    $pid = $videolist['id'];
    $video = $DB->getRow("SELECT * FROM `pre_video` WHERE pid='$pid' LIMIT 1");
} else {
    echo '参数错误！';
    exit;
}
?>
<!DOCTYPE html>  
<html lang="zh">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>短剧详情页</title>  
    <link href="//cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
    <script src="<?php echo $cdnpublic ?>layer/2.3/layer.js"></script>
    <style>
        body, html {  
            margin: 0;  
            padding: 0;  
            font-family: 'Arial', sans-serif;  
            color: #333;  
            overflow-x: hidden;  
            background: url('<?php echo $videolist['img'];?>') no-repeat center center fixed; /* 使用电影封面作为背景 */
            background-size: cover; /* 背景铺满 */
        }  

        .header {  
            position: fixed;  
            top: 0;  
            left: 0;
            width: 100%;  
            background-color: rgba(255, 255, 255, 0.9); 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;  
            justify-content: start;  
            align-items: center;  
            padding: 15px 30px;
            z-index: 1000;  
        }  

        .back-to-theater {  
            color: #007BFF;  
            text-decoration: none;  
            font-weight: bold;  
            font-size: 18px;  
        }  

        .content-wrapper {  
            position: relative;  
            min-height: 100vh;  
            padding-top: 80px; /* 根据header的高度调整 */  
            background-color: rgba(255, 255, 255, 0.8); /* 添加半透明的背景色以增强可读性 */
            backdrop-filter: blur(5px); /* 背景模糊效果 */
        }  

        .content {  
            max-width: 1200px;  
            margin: 0 auto;  
            padding: 20px;  
            background-color: #ffffff; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);  
            border-radius: 8px;  
        }  

        .drama-info h3 {  
            margin: 0;  
            color: #333;  
            font-size: 24px;  
        }  

        .drama-info p {  
            margin: 10px 0;  
            line-height: 1.5;  
        }

        .action-buttons {  
            display: flex;  
            flex-direction: column;  
            gap: 10px;  
            margin-top: 20px;  
        }  

        .action-buttons button {  
            padding: 10px 20px;  
            font-size: 16px;  
            border: none;  
            border-radius: 5px;  
            background-color: #007BFF;  
            color: white;  
            transition: background-color 0.3s;  
            cursor: pointer;  
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);  
        }  

        .action-buttons button:hover {  
            background-color: #0056b3;  
        }

        .episode-display {  
            display: flex;  
            flex-wrap: wrap;  
            gap: 15px;  
            margin-top: 20px;  
        }  

        .episode-item {  
            flex: 1 1 calc(33.333% - 20px); /* 每行三个剧集，并考虑间距 */  
            position: relative;  
            overflow: hidden;  
            border-radius: 8px; /* 圆角效果 */  
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);  
            transition: transform 0.2s;  
        }  

        .episode-item:hover {  
            transform: scale(1.05);  
        }  

        .episode-item img {  
            width: 100%;  
            height: auto;  
            display: block;  
            border-radius: 8px; /* 圆角效果 */  
        }  

        .episode-number {  
            position: absolute;  
            bottom: 0;  
            left: 0;  
            width: 100%;  
            background-color: rgba(0, 0, 0, 0.6);  
            color: white;  
            text-align: center;  
            padding: 5px 0;  
            margin: 0;  
            font-size: 14px;  
        }  

        .footer-nav {  
            background-color: rgba(51, 51, 51, 0.9); 
            color: #fff;  
            padding: 10px 0;  
            position: fixed;  
            bottom: 0;  
            left: 0;  
            right: 0;  
            text-align: center;  
        }  

        .footer-container {
            max-width: 1200px;  
            margin: 0 auto;  
            border-top: 1px solid #444;  
            padding-top: 10px;  
        }

        .footer-nav a {  
            color: #fff;  
            text-decoration: none;  
            margin: 0 15px;  
            font-size: 16px;  
        }  

        .footer-nav a:hover {  
            text-decoration: underline;  
        }  

        .modal {  
            display: none;  
            position: fixed;  
            z-index: 1;  
            left: 0;  
            width: 100%;  
            height: 100%;  
            overflow: auto;  
            background-color: rgba(0,0,0,0.4);  
        }  

        .modal-content {  
            background-color: #fefefe;  
            margin: 15% auto;  
            padding: 20px;  
            border: 1px solid #888;  
            width: 80%;  
            max-width: 500px;  
        }  

        .modal-header {  
            text-align: center;  
            font-size: 20px;  
        }  

        .modal-body {  
            text-align: center;  
            padding: 10px;  
        }

        .buy-btn {  
            display: inline-block;  
            padding: 10px 20px;  
            font-size: 16px;  
            color: #fff;  
            background-color: #007bff;  
            border: none;  
            border-radius: 5px;  
            cursor: pointer;  
            transition: background-color 0.3s;  
        }  
        
        .buy-btn:hover {  
            background-color: #0056b3;  
        }  

        .buy-btn:disabled {  
            background-color: #ccc;  
            color: #666;  
            cursor: not-allowed;  
        }  
    </style>  
</head>  
<body>  
<div class="container">
    <div class="header">  
        <a href="JavaScript:history.back();" class="back-to-theater">< 返回</a>  
    </div>  
    <div class="content-wrapper">  
        <div class="content">  
            <div class="drama-info">  
                <h3><?php echo $videolist['name'];?></h3>  
                <p><?php echo $videolist['desc'];?></p>  
            </div>  
            <div class="action-buttons">  
                <?php if(!empty($videolist['download_url']) && empty($pay_url_log)){?>
                    <button onclick="showOrderModal('url')">购买网盘下载地址</button> 
                <?php }?>
                
                <?php if(!empty($video) && empty($pay_play_log)){?>
                    <button onclick="showOrderModal('play')">购买全集播放权限</button> 
                <?php }?>
            </div>  
            <div class="episode-display">  
            <?php 
                $query = "SELECT * FROM `pre_video` WHERE pid='$id' ORDER BY `num` ASC";
                $result = $DB->query($query);
                while ($row = $result->fetch()) {
                    echo '<div class="episode-item"> 
                          <a href="?mod=play&id='.$row['id'].'"> 
                          <img src="'.$videolist['img'].'" alt="第'.$row['num'].'集" >  
                          <p class="episode-number">第'.$row['num'].'集</p>  
                          </a>
                          </div>'; 
                }
            ?>
            </div>  
        </div>  
    </div>
</div>    
<footer class="footer-nav">
    <div class="footer-container">
        <nav>
            <a href="/">首页</a>
            <a href="./?mod=cart">购物车</a>
            <a href="./?mod=fenlei">分类</a>
            <a href="./?mod=query">订单</a>
            <a href="./?mod=kf">客服</a>
            <a href="./user/">会员中心</a>
        </nav>
    </div>
</footer>
<script src="assets/store/js/main.js?ver=<?php echo VERSION ?>"></script>
<script>
function showOrderModal(type) {  
    var name = "<?php echo $videolist['name']?>";
    var goods_name, price;
    
    if(type === 'play'){
        goods_name = '购买' + name + '全集播放权限'; 
        price = "<?php echo $bfprice?>";
    } else if(type === 'url'){
        goods_name = '购买' + name + '网盘下载地址'; 
        price = "<?php echo $price?>";
    }
    
    var modalHTML = `<div id="orderModal" class="modal">  
        <div class="modal-content">  
            <h3 class="modal-header">下单信息</h3>  
            <div class="modal-body">
                <p>商品信息: <span>` + goods_name + `</span></p>  
                <p>商品价格: ￥<span style="color:red" id="productPrice">` + price + `</span></p>  
                <button class="buy-btn" onclick="confirmPurchase('` + type + `')">立即购买</button>  
                <button class="buy-btn" onclick="cancelOrder()">取消订单</button> <!-- 添加取消按钮 -->
            </div>  
        </div>  
    </div>`;  
  
    document.body.innerHTML += modalHTML;  
    var modal = document.getElementById("orderModal");  
    modal.style.display = "block";  
}  

function cancelOrder() {
    var modal = document.getElementById("orderModal");
    modal.style.display = "none"; // 关闭模态框
} 
  
function confirmPurchase(type) {  
    var vid = <?php echo $id;?>;
    $.ajax({
        type : "POST",
        url : "ajax.php?act=payvideo",
        data : {
            vid: vid,
            goods_type: type
        },
        dataType : 'json',
        success : function(data) {
            if (data.code == 0) {
                var paymsg = '';
                if (data.pay_alipay > 0) {
                    paymsg += `<button class="btn btn-default btn-block" onclick="dopay('alipay','` + data.trade_no + `')" style="margin-top:10px;">
                                <img src="assets/img/alipay.png" style="width:30px" class="logo">支付宝购买，请在个人中心充值余额</button>`;
                }
                if (data.pay_qqpay > 0) {
                    paymsg += `<button class="btn btn-default btn-block" onclick="dopay('qqpay','` + data.trade_no + `')" style="margin-top:10px;">
                                <img src="assets/img/qqpay.png" style="width:30px" class="logo">QQ钱包</button>`;
                }
                if (data.pay_wxpay > 0) {
                    paymsg += `<button class="btn btn-default btn-block" onclick="dopay('wxpay','` + data.trade_no + `')" style="margin-top:10px;">
                                <img src="assets/img/wxpay.png" style="width:30px" class="logo">微信支付（可直接购买）</button>`;
                }
                if (data.pay_rmb > 0) {
                    paymsg += `<button class="btn btn-default btn-block" onclick="dopay('rmb','` + data.trade_no + `')" style="margin-top:10px;">
                                <img src="assets/img/rmb.png" style="width:30px" class="logo">余额支付（可直接使用）<span class="text-muted">(剩` + data.user_rmb + `元)</span></button>`;
                }
                if (data.paymsg != null) paymsg += data.paymsg;
                layer.alert('<center><h2>￥ ' + data.need + '</h2><hr>' + paymsg + '<hr><a class="btn btn-default btn-block" onclick="cancel(` + data.trade_no + `)">取消订单</a></center>', {
                    btn: [],
                    title: '提交订单成功',
                    closeBtn: false
                });
            } else if (data.code == 1) {
                alert('领取成功！');
                window.location.href = '?buyok=1';
            } else {
                layer.alert(data.msg);
            }
        }
    });

    var modal = document.getElementById("orderModal");  
    modal.style.display = "none";  
}  
  
document.addEventListener("DOMContentLoaded", function() {  
    var modals = document.getElementsByClassName("modal");  
    for (var i = 0; i < modals.length; i++) {  
        modals[i].style.display = "none"; 
        modals[i].addEventListener('click', function(e) {  
            if (e.target == this) {  
                this.style.display = "none";  
            }  
        });  
    }  
});  
</script>
</body>  
</html>