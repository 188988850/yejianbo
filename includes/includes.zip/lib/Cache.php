<?php
namespace lib;

class Cache {
	private $cache_path;
	private $cache_time;
	
	public function __construct($cache_path = null, $cache_time = 3600) {
		$this->cache_path = $cache_path ?: ROOT.'cache/';
		$this->cache_time = $cache_time;
		
		if(!is_dir($this->cache_path)) {
			mkdir($this->cache_path, 0777, true);
		}
	}
	
	public function set($key, $value, $time = null) {
		$time = $time ?: $this->cache_time;
		$data = [
			'time' => time(),
			'expire' => $time,
			'data' => $value
		];
		return file_put_contents($this->cache_path.md5($key).'.cache', serialize($data));
	}
	
	public function get($key) {
		$file = $this->cache_path.md5($key).'.cache';
		if(!file_exists($file)) {
			return false;
		}
		
		$data = unserialize(file_get_contents($file));
		if($data['time'] + $data['expire'] < time()) {
			unlink($file);
			return false;
		}
		
		return $data['data'];
	}
	
	public function delete($key) {
		$file = $this->cache_path.md5($key).'.cache';
		if(file_exists($file)) {
			return unlink($file);
		}
		return true;
	}
	
	public function clear() {
		$files = glob($this->cache_path.'*.cache');
		foreach($files as $file) {
			unlink($file);
		}
		return true;
	}
}
