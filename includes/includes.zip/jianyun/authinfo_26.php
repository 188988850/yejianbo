<?php
$edition = '1.0.0';
$version = 1000;