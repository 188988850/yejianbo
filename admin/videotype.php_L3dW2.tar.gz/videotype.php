<?php
/**
 * 秒杀商品列表
**/
include("../includes/common.php");
$title='短剧列表';
include './head.php';

if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<script src="https://code.jquery.com/jquery-3.0.0.min.js"></script>
<link rel="stylesheet" href="https://www.jq22.com/demo/TGTool202007201551/TGTool.css">
<script src="https://www.jq22.com/demo/TGTool202007201551/TGTool.js"></script>
<div class="col-md-12 center-block" style="float: none;">
        
<?php

adminpermission('shop', 1);

$my=isset($_GET['my'])?$_GET['my']:null;


if($my=='add')
{
?>

<div class="block">
<div class="block-title"><h3 class="panel-title">添加短剧分类</h3></div>
<div class="">
  <input type="file" onchange="tximg()" style="display: none;" id="tx">  
  <form action="./videotype.php?my=add_submit" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			分类名称
		</span>
		<input type="text" id="name" name="name" value="" class="form-control" placeholder="输入分类名称" required/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序
		</span>
		<input type="number" id="sort" name="sort" value="1" class="form-control" required/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="添加" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./videotype.php">>>返回短剧分类列表</a>
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<?php
}
elseif($my=='edit')
{
$id=$_GET['id'];
$row=$DB->getRow("select * from pre_videotype where id='$id' limit 1");
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">修改短剧分类</h3></div>
<div class="">
  <input type="file" onchange="tximg1()" style="display: none;" id="tx1">  
  <form action="./videotype.php?my=edit_submit&id=<?php echo $id; ?>" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			分类名称
		</span>
		<input type="text" id="name" value="<?php echo $row['name']; ?>" class="form-control" disabled/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序
		</span>
		<input type="number" id="sort" name="sort" value="<?php echo $row['sort']; ?>" class="form-control" required/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./videotype.php">>>返回短剧列表</a>
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<?php
}
elseif($my=='add_submit')
{
$name=$_POST['name'];
$sort = $_POST['sort']; 
$addtime = date('Y-m-d H:i:s');

if($name==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
$sql="insert into `pre_videotype` (`name`,`sort`,`addtime`) values ('".$name."','".$sort."','".$addtime."')";
if($DB->exec($sql)!==false){
	showmsg('添加短剧分类成功！<br/><br/><a href="./videotype.php">>>返回短剧列表</a>',1);
}else
	showmsg('添加短剧分类失败！'.$DB->error(),4);
}
}
elseif($my=='edit_submit')
{
$id=$_GET['id'];
$rows=$DB->getRow("select * from pre_videotype where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
	
$name=$_POST['name'];
$sort = $_POST['sort']; 

if($name==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
if($DB->exec("UPDATE `pre_videotype` SET `name`='".$name."',`sort`='".$sort."' WHERE `id`='".$id."'")!==false)
	showmsg('修改短剧分类成功！<br/><br/><a href="./videotype.php">>>返回短剧分类列表</a>',1);
else
	showmsg('修改短剧分类失败！'.$DB->error(),4);
}
}
else
{
?>
<div class="block">
<div class="block-title clearfix">
<h2 id="blocktitle"></h2>
<span class="pull-right"><select id="pagesize" class="form-control"><option value="30">30</option><option value="50">50</option><option value="60">60</option><option value="80">80</option><option value="100">100</option></select><span>
</span></span>
</div>
  <form onsubmit="return searchItem()" method="GET" class="form-inline">
  <a href="./videotype.php?my=add" class="btn btn-primary"><i class="fa fa-plus"></i>&nbsp;添加短剧分类</a>
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="请输入短剧分类名称">
  </div>
  <button type="submit" class="btn btn-info">搜索</button>&nbsp;
  <a href="javascript:listTable('start')" class="btn btn-default" title="刷新短剧分类列表"><i class="fa fa-refresh"></i></a>
</form>
<div id="listTable"></div>
  </div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<script src="assets/js/videotype.js?ver=<?php echo VERSION ?>"></script>
<?php }?>
</body>
</html>