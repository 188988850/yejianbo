<?php
require_once '../admin_check.php';
require_once '../includes/common.php';

$id = intval($_GET['id']);
$sql = "SELECT * FROM `{$dbconfig['dbqz']}_news` WHERE id=$id";
$row = $DB->fetch($DB->query($sql));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $cover_url = $_POST['cover_url'];
    $public_content = $_POST['public_content'];
    $vip_content = $_POST['vip_content'];
    $sql = "UPDATE `{$dbconfig['dbqz']}_news` SET title=?, cover_url=?, public_content=?, vip_content=? WHERE id=?";
    $stmt = $DB->prepare($sql);
    $stmt->bind_param('ssssi', $title, $cover_url, $public_content, $vip_content, $id);
    $stmt->execute();
    header('Location: news.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>编辑资讯</title>
</head>
<body>
    <h1>编辑资讯</h1>
    <form method="post">
        <p>标题：<input type="text" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" required></p>
        <p>封面图URL：<input type="text" name="cover_url" value="<?php echo htmlspecialchars($row['cover_url']); ?>"></p>
        <p>商品介绍(public_content)：<br><textarea name="public_content" rows="8" cols="60"><?php echo htmlspecialchars($row['public_content']); ?></textarea></p>
        <p>会员可见内容(vip_content)：<br><textarea name="vip_content" rows="8" cols="60"><?php echo htmlspecialchars($row['vip_content']); ?></textarea></p>
        <button type="submit">保存</button>
    </form>
    <a href="news.php">返回列表</a>
</body>
</html>