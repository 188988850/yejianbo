<?php
require_once '../admin_check.php';
require_once '../includes/common.php';

$id = intval($_GET['id']);
$sql = "DELETE FROM `{$dbconfig['dbqz']}_news` WHERE id=$id";
$DB->query($sql);
header('Location: news.php');
exit;