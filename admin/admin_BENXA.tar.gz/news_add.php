<?php
require_once '../admin_check.php';
require_once '../includes/common.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $cover_url = $_POST['cover_url'];
    $public_content = $_POST['public_content'];
    $vip_content = $_POST['vip_content'];
    $add_time = date('Y-m-d H:i:s');
    $sql = "INSERT INTO `{$dbconfig['dbqz']}_news` (title, cover_url, add_time, public_content, vip_content) VALUES (?, ?, ?, ?, ?)";
    $stmt = $DB->prepare($sql);
    $stmt->bind_param('sssss', $title, $cover_url, $add_time, $public_content, $vip_content);
    $stmt->execute();
    header('Location: news.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>添加资讯</title>
</head>
<body>
    <h1>添加资讯</h1>
    <form method="post">
        <p>标题：<input type="text" name="title" required></p>
        <p>封面图URL：<input type="text" name="cover_url"></p>
        <p>商品介绍(public_content)：<br><textarea name="public_content" rows="8" cols="60"></textarea></p>
        <p>会员可见内容(vip_content)：<br><textarea name="vip_content" rows="8" cols="60"></textarea></p>
        <button type="submit">提交</button>
    </form>
    <a href="news.php">返回列表</a>
</body>
</html>